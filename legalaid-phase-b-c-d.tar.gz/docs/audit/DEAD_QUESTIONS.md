# Phase D2.2 — intake questions with no destination

**148 dead question-instances across 35 families.** A question is dead
here only when changing the answer leaves the clause set, every clause's length and
every requirement outcome identical — measured by generating twice, not by failing to
find a consumer in the source.

| family | shape | asked | dead | fields |
|---|---|---|---|---|
| TERM_SHEET | AGREEMENT | 7 | **6** | termination_for_convenience, termination_for_cause, include_non_compete, include_non_solicit, include_sla, include_reporting |
| ESOP_GRANT_LETTER | AGREEMENT | 6 | **6** | termination_for_convenience, termination_for_cause, include_non_compete, include_non_solicit, include_sla, include_reporting |
| SHARE_SUBSCRIPTION_AGREEMENT | AGREEMENT | 7 | **6** | termination_for_convenience, termination_for_cause, include_non_compete, include_non_solicit, include_sla, include_reporting |
| PROMISSORY_NOTE | AGREEMENT | 6 | **6** | termination_for_convenience, termination_for_cause, include_non_compete, include_non_solicit, include_sla, include_reporting |
| IP_ASSIGNMENT_AGREEMENT | AGREEMENT | 7 | **6** | termination_for_convenience, termination_for_cause, include_non_compete, include_non_solicit, include_sla, include_reporting |
| REFUND_AND_CANCELLATION_POLICY | POLICY | 6 | **6** | termination_for_convenience, termination_for_cause, include_non_compete, include_non_solicit, include_sla, include_reporting |
| SHIPPING_AND_DELIVERY_POLICY | POLICY | 6 | **6** | termination_for_convenience, termination_for_cause, include_non_compete, include_non_solicit, include_sla, include_reporting |
| SEPARATION_AGREEMENT | AGREEMENT | 7 | **6** | termination_for_convenience, termination_for_cause, include_non_compete, include_non_solicit, include_sla, include_reporting |
| POSH_POLICY | POLICY | 6 | **6** | termination_for_convenience, termination_for_cause, include_non_compete, include_non_solicit, include_sla, include_reporting |
| SETTLEMENT_AGREEMENT | AGREEMENT | 7 | **6** | termination_for_convenience, termination_for_cause, include_non_compete, include_non_solicit, include_sla, include_reporting |
| SOFTWARE_DEVELOPMENT_AGREEMENT | AGREEMENT | 10 | **6** | include_warranty_clause, include_nomenclature_clause, include_non_compete, include_non_solicit, include_sla, include_reporting |
| JOINT_VENTURE_AGREEMENT | AGREEMENT | 6 | **5** | termination_for_convenience, termination_for_cause, include_non_compete, include_non_solicit, include_reporting |
| SUPPLY_AGREEMENT | AGREEMENT | 8 | **5** | include_inspection_rights, include_non_compete, include_non_solicit, include_sla, include_reporting |
| DATA_PROCESSING_AGREEMENT | AGREEMENT | 7 | **4** | include_non_compete, include_non_solicit, include_sla, include_reporting |
| APPOINTMENT_LETTER | AGREEMENT | 7 | **4** | include_non_compete, include_non_solicit, include_sla, include_reporting |
| INTERNSHIP_AGREEMENT | AGREEMENT | 7 | **4** | include_non_compete, include_non_solicit, include_sla, include_reporting |
| EMPLOYMENT_CONTRACT | AGREEMENT | 7 | **4** | termination_for_convenience, termination_for_cause, include_sla, include_reporting |
| COMMERCIAL_LEASE_AGREEMENT | AGREEMENT | 5 | **4** | termination_for_convenience, termination_for_cause, include_non_compete, include_non_solicit |
| LEAVE_AND_LICENSE_AGREEMENT | AGREEMENT | 6 | **4** | termination_for_convenience, termination_for_cause, include_non_compete, include_non_solicit |
| GUARANTEE_AGREEMENT | AGREEMENT | 5 | **4** | termination_for_convenience, termination_for_cause, include_non_compete, include_non_solicit |
| VENDOR_AGREEMENT | AGREEMENT | 7 | **4** | include_non_compete, include_non_solicit, include_sla, include_reporting |
| TERMS_OF_SERVICE | POLICY | 4 | **4** | termination_for_convenience, termination_for_cause, include_non_compete, include_non_solicit |
| PRIVACY_POLICY | POLICY | 4 | **4** | termination_for_convenience, termination_for_cause, include_non_compete, include_non_solicit |
| RENTAL_AGREEMENT | AGREEMENT | 5 | **4** | termination_for_convenience, termination_for_cause, include_non_compete, include_non_solicit |
| FOUNDERS_AGREEMENT | AGREEMENT | 8 | **3** | include_non_solicit, include_sla, include_reporting |
| PARTNERSHIP_DEED | AGREEMENT | 6 | **3** | include_non_compete, include_non_solicit, include_reporting |
| SHAREHOLDERS_AGREEMENT | AGREEMENT | 6 | **3** | include_non_compete, include_non_solicit, include_reporting |
| DISTRIBUTION_AGREEMENT | AGREEMENT | 7 | **3** | include_non_compete, include_non_solicit, include_sla |
| SALES_OF_GOODS_AGREEMENT | AGREEMENT | 5 | **3** | include_inspection_rights, include_non_compete, include_non_solicit |
| INDEPENDENT_CONTRACTOR_AGREEMENT | AGREEMENT | 10 | **3** | include_nomenclature_clause, include_sla, include_reporting |
| MOU | AGREEMENT | 6 | **3** | include_force_majeure, include_non_compete, include_non_solicit |
| SERVICE_AGREEMENT | AGREEMENT | 10 | **2** | include_nomenclature_clause, include_non_compete |
| LOAN_AGREEMENT | AGREEMENT | 5 | **2** | include_non_compete, include_non_solicit |
| MASTER_SERVICE_AGREEMENT | AGREEMENT | 7 | **2** | include_non_compete, include_reporting |
| CONSULTANCY_AGREEMENT | AGREEMENT | 10 | **1** | include_nomenclature_clause |

---

## What this is, and what it is not

Every row is a question the intake puts to a user whose answer the document
cannot act on. Answering it "No" produces byte-identical output to answering it
"Yes": same clauses, same clause lengths, same requirement outcomes.

That is invariant 34's shape — *the intake and the knowledge disagreeing about
what is decidable* — at portfolio scale. It is the mirror of invariant 30, where
a question offered an answer the product could not produce a document for.

**It is NOT 148 broken gates.** Most of these fields are commercial-contract
questions exposed on `VARIABLE_CONFIG.COMMON` and inherited by families that have
no use for them: `include_non_compete` and `include_sla` on a promissory note,
`termination_for_cause` on a refund policy, both on a POSH policy. The field
works perfectly where it belongs. It is asked where it does not.

## The measurement error, for the record

The first run reported **155** and included `include_indemnity_clause` on
SOFTWARE_DEVELOPMENT_AGREEMENT — a gate repaired in Phase C3 and guarded by
`tests/positionOverride.test.mjs`.

The probe mutated each field to "any option other than the current one". That
select's options are `["AI Recommended", "Yes", "No"]` and the fixture answers
"Yes", so the probe picked **"AI Recommended"**, which normalises the same way
"Yes" does. The gate never closed. A working field read as dead.

Corrected to mutate to the option that actually means NO — `positionOf(o) ===
FALSE` — and to skip any field offering no such option, since a question with no
"no" has no decline to test. 155 → 148.

**The fifth measurement error of this exact shape in this work**, after the
swapped derivation arguments, the `invalid_if` prose filter, the gate-name
versus field-name gap, and the `options[0]` fixture premise. Each time the probe
answered a different question from the one it was asked, and each time the wrong
number was larger than the right one. The pattern is worth stating plainly: a
probe that over-reports is not erring on the safe side, because an inflated
finding gets acted on.

## Why this is not repaired here

Withdrawing a question is cheap per field and wrong in bulk. Each instance needs
the same adjudication the entire-agreement case got: does the family's own
knowledge say the clause does not belong, or does the family need the gate and
simply lack it? Those have opposite repairs — withdraw the question, or author
the gate — and telling them apart requires reading the family's artifacts.

Recorded as the population for a scoped pass, family by family, starting with the
one POSH needs.
