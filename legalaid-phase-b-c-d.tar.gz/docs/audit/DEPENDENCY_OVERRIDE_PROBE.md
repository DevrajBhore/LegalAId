# Phase C1 — where a dependency outranks an applicability gate

Gates stated across all blueprints: **117**  
Gates actually CLOSED by declining the flag: **62**  
Gates that could not be closed — the flag is not an answerable intake field on that 
family, or the derivation overrides the answer: 52  
Gates OVERRIDDEN — the clause ships although the user declined it: **1**  
Gates whose fixture could not generate with the flag declined: 3

Route taken by each override: {"dependencyResolver":1}

## Overridden

| document type | clause | declined flag | injected by |
|---|---|---|---|
| SALES_OF_GOODS_AGREEMENT | SUPPLY_INSPECTION_001 | include_inspection_rights | dependencyResolver |

## Gates this probe could not close

**A LIMIT OF THE MEASUREMENT, NOT A LIST OF DEFECTS.** To close a gate the probe must
know which intake question backs it, and the gate's name is not always the field's
name — LOAN_SECURITY_001 is gated on `is_secured` while the question is called
`loan_is_secured`. That mapping is stated for the seven declared semantic facts and
nowhere else, so for the rest the probe writes into a key the schema does not have,
sanitisation drops it, and the gate stays open.

Some of these are probably gates written against a control no user can answer, which
would be a real defect. Others are simply names this probe cannot resolve. Until the
mapping exists they cannot be told apart, so the number is reported and not read.

| document type | clause | flag |
|---|---|---|
| APPOINTMENT_LETTER | EMP_POSH_POLICY_001 | employer_headcount_ge_10 |
| APPOINTMENT_LETTER | EMP_ESOP_001 | has_esop_or_variable_pay |
| COMMERCIAL_LEASE_AGREEMENT | CORE_INSURANCE_001 | include_insurance |
| CONSULTANCY_AGREEMENT | SERVICE_DELIVERABLES_001 | include_deliverables |
| CONSULTANCY_AGREEMENT | SERVICE_SLA_001 | include_sla |
| CONSULTANCY_AGREEMENT | CORE_INSURANCE_001 | include_insurance |
| CONSULTANCY_AGREEMENT | CORE_GOVERNANCE_PROTECTIONS_001 | include_governance_protections |
| CONSULTANCY_AGREEMENT | SERVICE_TIMELINES_001 | include_timelines |
| CONSULTANCY_AGREEMENT | SERVICE_REPORTING_001 | include_reporting |
| CONSULTANCY_AGREEMENT | SERVICE_ACCEPTANCE_001 | include_inspection_rights |
| CONSULTANCY_AGREEMENT | IP_INFRINGEMENT_001 | include_ip_assignment |
| CONSULTANCY_AGREEMENT | CORE_TRANSITION_ASSISTANCE_001 | include_transition_assistance |
| CONSULTANCY_AGREEMENT | SERVICE_EXPENSES_001 | include_expenses |
| CONSULTANCY_AGREEMENT | SERVICE_CHANGE_REQUEST_001 | include_change_control |
| DISTRIBUTION_AGREEMENT | DIST_COMPETITION_COMPLIANCE_001 | include_competition_compliance |
| DISTRIBUTION_AGREEMENT | SERVICE_REPORTING_001 | reporting_required |
| DISTRIBUTION_AGREEMENT | CORE_INSURANCE_001 | include_insurance |
| DISTRIBUTION_AGREEMENT | CORE_GOVERNANCE_PROTECTIONS_001 | include_governance_protections |
| EMPLOYMENT_CONTRACT | EMP_MOONLIGHTING_001 | restrict_moonlighting |
| EMPLOYMENT_CONTRACT | EMP_MATERNITY_BENEFITS_001 | is_female_employee |
| INDEPENDENT_CONTRACTOR_AGREEMENT | SERVICE_DELIVERABLES_001 | include_deliverables |
| INDEPENDENT_CONTRACTOR_AGREEMENT | CORE_INSURANCE_001 | include_insurance |
| INDEPENDENT_CONTRACTOR_AGREEMENT | CORE_GOVERNANCE_PROTECTIONS_001 | include_governance_protections |
| IP_ASSIGNMENT_AGREEMENT | IPA_COPYRIGHT_ASSIGNMENT_001 | assigns_copyright |
| JOINT_VENTURE_AGREEMENT | CORE_DATA_PROCESSING_001 | jv_processes_personal_data |
| JOINT_VENTURE_AGREEMENT | CORE_INSURANCE_001 | include_insurance |
| JOINT_VENTURE_AGREEMENT | CORE_GOVERNANCE_PROTECTIONS_001 | include_governance_protections |
| LOAN_AGREEMENT | GUARANTEE_OBLIGATION_001 | personal_guarantee_required |
| MASTER_SERVICE_AGREEMENT | CORE_INSURANCE_001 | include_insurance |
| MASTER_SERVICE_AGREEMENT | CORE_GOVERNANCE_PROTECTIONS_001 | include_governance_protections |
| MASTER_SERVICE_AGREEMENT | MSA_GOVERNANCE_BODY_001 | include_governance_protections |
| MASTER_SERVICE_AGREEMENT | SERVICE_CUSTOMER_DEPENDENCIES_001 | include_deliverables |
| MASTER_SERVICE_AGREEMENT | CORE_RESIDUAL_KNOWLEDGE_001 | include_confidentiality |
| PARTNERSHIP_DEED | CORE_DATA_PROCESSING_001 | firm_processes_personal_data |
| RENTAL_AGREEMENT | RENT_SUBLEASE_001 | subletting_addressed |
| SERVICE_AGREEMENT | SERVICE_DELIVERABLES_001 | include_deliverables |
| SERVICE_AGREEMENT | CORE_INSURANCE_001 | include_insurance |
| SERVICE_AGREEMENT | CORE_GOVERNANCE_PROTECTIONS_001 | include_governance_protections |
| SHAREHOLDERS_AGREEMENT | CORE_DATA_PROCESSING_001 | company_processes_personal_data |
| SUPPLY_AGREEMENT | SUPPLY_SHORTAGE_001 | shortage_risk |
| SUPPLY_AGREEMENT | SUPPLY_RETURN_POLICY_001 | return_policy_required |
| SUPPLY_AGREEMENT | CORE_INSURANCE_001 | include_insurance |
| SUPPLY_AGREEMENT | CORE_GOVERNANCE_PROTECTIONS_001 | include_governance_protections |
| SOFTWARE_DEVELOPMENT_AGREEMENT | CORE_INSURANCE_001 | include_insurance |
| SOFTWARE_DEVELOPMENT_AGREEMENT | CORE_GOVERNANCE_PROTECTIONS_001 | include_governance_protections |
| VENDOR_AGREEMENT | CORE_INSURANCE_001 | include_insurance |
| VENDOR_AGREEMENT | CORE_CONFIDENTIALITY_001 | include_confidentiality |
| VENDOR_AGREEMENT | SUPPLY_SHORTAGE_001 | include_delivery_terms |
| VENDOR_AGREEMENT | SUPPLY_RETURN_POLICY_001 | return_policy_required |
| VENDOR_AGREEMENT | SUPPLY_PRICE_REVISION_001 | include_price_revision |
| VENDOR_AGREEMENT | CORE_INDEMNITY_001 | include_indemnity_clause |
| VENDOR_AGREEMENT | CORE_TRANSITION_ASSISTANCE_001 | include_transition_assistance |

## Not exercised — the fixture does not generate with the flag declined

These are NOT clean gates. Each is a state the family may not be able to represent,
the shape Phase B found on the loan, and each needs its own look.

| document type | clause | declined flag | refused with |
|---|---|---|---|
| EMPLOYMENT_CONTRACT | EMP_POSH_POLICY_001 | employer_headcount_ge_10 |  |
| LOAN_AGREEMENT | LOAN_SARFAESI_ENFORCEMENT_001 | lender_is_regulated |  |
| TERMS_OF_SERVICE | TOS_FEES_AND_BILLING_001 | is_paid_service |  |

---

# C3 / C4 — the invariant, and the six stages that violated it

## The invariant

> Once clause selection has established that a candidate was
> applicability-excluded, **no later generation stage may reintroduce it** — nor
> anything that fills its role — unless an explicitly stronger, governed rule
> authorises that reintroduction.

## How the exclusion is carried

`resolveClauseSelection` records `applicabilityExcludedClauseIds`: conditionals
whose own `include_if` evaluated false and which did not survive by another
route. Deliberately NOT variant-replaced, suppressed, document-incompatible, or
never-a-candidate — each of those has its own record, and folding them together
would leave later stages unable to tell *the user declined this* from *this was
never on the table*.

Written to metadata whenever selection runs, so **absent and empty are different
facts**: empty means the gates excluded nothing; absent means nobody evaluated a
gate, and a conditional dependency must refuse rather than assume.

## The dependency distinction

| | meaning | behaviour |
|---|---|---|
| `depends_on` | STRUCTURAL — clause A is incomplete without B | injected regardless of the gate |
| `required_with` | CONDITIONAL — B is required when B itself applies | injected only if B was not gate-excluded |

Where no applicability record reached the resolver, `required_with` is refused
and a diagnostic recorded on `metadata.dependency_diagnostics`. Not thrown:
generation must not die because a repair path handed over a draft without
selection metadata. Never injected, because that is the original defect wearing
a new API.

## Six stages could reintroduce an excluded clause

Each was found by the previous one's repair failing to hold.

| # | stage | what it did |
|---|---|---|
| 1 | `dependencyResolver` — `required_with` | injected the target whatever the gate decided |
| 2 | `documentHardening` baseline clause set | re-added any baseline clause missing, filtering replaced/conflicting/disallowed but not excluded |
| 3 | `documentHardening` missing-clause reporting | then charged the document HIGH for the absence it had stopped curing |
| 4 | general-provisions constraints | reported a DECLINED default as a missing requirement |
| 5 | protection injector (`injectProtection`) | added a **different clause id filling the same role** — declining `CORE_FORCE_MAJEURE_001` yielded `CORE_FORCE_MAJEURE_FALLBACK_001`, passing every id-for-id check while the document carried the very provision the user turned down |
| 6 | blueprint gating of floor clauses | four `defaults.hardening` clauses gated `== true` in 33 places, so silence removed them — invisible while stage 2 put them back |

**Overridden gates: 33 → 1.** The one remaining is a `depends_on` edge
(`SUPPLY_REJECTION_001 → SUPPLY_INSPECTION_001`), which is structural by
declaration; whether that declaration is legally right is knowledge review, not
an engine defect. `positionOverride.test.mjs` now records **0 overridden, 4
respected** — the respected list is what keeps the zero honest, since a bug
dropping every conditional clause would also produce an empty override list.

## The floor-vs-default adjudication

`CORE_ENTIRE_AGREEMENT_001`, decided from the artifacts rather than from taste.

| artifact | says |
|---|---|
| `drafting_policies.json` | the list lives under **`defaults.hardening`** — and is tuned per family, empty for policies and notices, curated for settlement |
| `general_provisions.constraints.json` | severity **MEDIUM**, worded "**should** contain", `review_status: draft-needs-legal-review` |
| `variableConfig.js` | "Universally applicable **optional protection** — offered on every type", `required: false`, options `["No", "Yes"]` |

All thirteen baseline rules are MEDIUM. Nine of the thirteen clauses carry no
gate at all; the four that do are exactly the four exposed to the user as
choices. **Every declaration that speaks to optionality says optional, and
nothing says mandatory. This is Model B — a default.**

So:

- the four floor clauses were re-gated `== true` → `!= false`, this codebase's
  documented idiom for *include unless declined*. Silence keeps them, matching
  the default set; an explicit "No" now genuinely removes them, which opt-in
  gating never actually achieved because stage 2 put the clause back.
- the constraint engine gained a **`declined`** outcome, alongside its existing
  `pass` / `fail` / `not_applicable` / `no_assertion`. Where the only unmet
  clause is one the user's own gate excluded, the rule is not describing a defect
  in the document; it is describing a choice the product offered and the user
  made. Recorded and visible, but not a violation and not a deduction.

Clean-scoring document types went 19/40 → 29/40, and for the right reason. The
remaining shortfalls are pre-existing fixture defects — an invalid GSTIN check
digit, a CIN on an LLP, a liability cap answered two ways — none of them caused
by applicability.

## Baselines re-recorded, deliberately

Both frozen corpora drifted, in one direction only: clauses the fixtures had
**declined** stopped being forced into the document. Verified mechanically before
re-recording — across 32 drifted answer-state rows, every change was a removal
except one role substitution, since repaired at stage 5.

One genuinely new advisory appeared: `INPUT_MISMATCH_EXPENSES_POLICY`. The
fixture supplies an expenses policy while declining the expenses clause, and the
system now says so instead of silently shipping the clause. That is the intake
contradiction being surfaced, not a regression.

## Still open

- **The 52 gates this probe cannot close.** A measurement limit: the gate's name
  is not the intake field's name, and the mapping is stated only for the seven
  declared semantic facts.
- **Fixture semantics.** The sweep fixture takes `options[0]`, which is "No", so
  it declines every optional protection — it cannot also be the "well-filled
  document" one health test names. Two fixtures are needed
  (`MINIMAL_DECLINED`, `WELL_FILLED`), each stating what it tests.
- **The remaining `depends_on` edges.** Knowledge review, not engine work.

---

# C-final — fixture separation, and the last edge

## The fixture was answering a question nobody asked it

`variablesFor` answered every select with `options[0]`, and for the optional
protections `options[0]` is `"No"`. So the health tests asked whether **a
well-filled document** carries its general provisions while the fixture was
declining every one of them.

Invisible until Phase C: the hardening baseline reinstated whatever the fixture
declined, so the answer changed nothing and the premise could not be caught.

Two named profiles now — `MINIMAL_DECLINED` and `WELL_FILLED` — differing in
exactly one dimension: optional `include_*` drafting choices.

A first attempt keyed on **shape** alone (any optional yes/no select) also
flipped `addressee_is_government`, `involves_source_code`, `company_has_ip_assets`
and `jv_involves_equity`. Those are facts about the world. Answering them "Yes"
does not make a document better filled in — it makes it a **different document**,
about a government addressee or about source code — and the health tests would
then have been comparing two unlike things and calling the difference
completeness. Narrowed to the `include_*` convention, which is what this codebase
uses for a drafting choice; `semantic_facts.json` draws the same line in its own
words about `include_sla`: *"A drafting choice, not a fact about the world."*

`documentHealthScore` now reads `WELL_FILLED`, which is what its own name means.
The other half is `tests/declinedProtections.test.mjs`.

## Protection-role conservation

The general form of the fallback fix, as a test rather than a one-off repair:

> A declined protection role must not be satisfied by ANY clause unless an
> authored substitution explicitly permits it.

**32 declined roles occupied by nothing; 40 accepted roles occupied.** Both
directions, because a bug dropping every conditional clause would satisfy the
first half perfectly.

It immediately found two more populations the id-level work had missed:

- **21 families had no gate for `CORE_ENTIRE_AGREEMENT_001` at all**, so the
  question was asked and the hardening default answered it. Gated in the 9 where
  the intake offers the question and the knowledge says the clause belongs.
- **10 of those 21 were notices, affidavits and policies** where the intake never
  offers the field. Gating them would have **added** an entire-agreement clause to
  an affidavit, because `!= false` includes on silence. Reverted — the
  over-application was caught by the clause baseline, not by reasoning.

## Two families where the question itself was the defect

ESOP grant letters and promissory notes are named in the constraint's
`excludes_doc_types` **and** carry their own hardening baseline omitting the
clause. Two authored artifacts agree it does not belong; the intake asked anyway,
and answering "Yes" changed nothing.

Withdrawn via `excludeDocuments` rather than honoured. Honouring it would put a
clause into two families whose own knowledge says it does not belong, on the
strength of an intake field nobody scoped to them.

## `declined` is now visible

`coverage.rules_declined` and `coverage.declined_defaults` carry the rule and the
clause ids. A clause absent *on purpose* is exactly what a reader should be told
about, and until now only its silence said so.

## The last edge: SUPPLY_REJECTION_001 → SUPPLY_INSPECTION_001

Not repaired. The engine is behaving exactly as the declaration says — it is
`depends_on`, which is structural — so this is knowledge review, and the question
is recorded on the clause as a `verification_flag` rather than settled by
deleting whichever artifact is inconvenient.

The evidence that makes it a real question: **`SUPPLY_REJECTION_001`'s own first
sentence already grants the inspection right** — *"The Buyer shall have the right
to inspect all Goods upon delivery"* — which is the whole of what
`SUPPLY_INSPECTION_001` says. Three outcomes are possible and they are not
equivalent: the edge is redundant; the edge is right and the duplicated sentence
should leave this clause; or the overlap is deliberate. Sections 41 and 42 of the
Sale of Goods Act, 1930 bear on it, since s.42 makes acceptance by conduct a
waiver of rejection — so how the two clauses interact is a question about waiver,
not tidiness.

## Phase C closing state

| | |
|---|---|
| Gates overridden by a dependency | **33 → 1**, and the 1 is `depends_on`, behaving as declared |
| `positionOverride` | 0 overridden, 4 respected |
| Protection roles | 32 declined empty, 40 accepted occupied |
| Clean-scoring document types | 19/40 → 29/40, on the fixture that means "well-filled" |
| Clause baseline | no drift across 40 types |
| Full suite | green |

**Open, and classified — none of it engine work:**

- `SUPPLY_REJECTION_001 → SUPPLY_INSPECTION_001` — knowledge review, flagged.
- `MOU / FORCE_MAJEURE` — the blueprint requires the clause while the intake
  offers a choice. Pinned by name in `declinedProtections.test.mjs`.
- Three fixture defects — an invalid GSTIN check digit, a CIN on an LLP, a
  liability cap answered two ways. Input defects, not reasons to relax validation.
- 52 gates this probe cannot close — a measurement ceiling, because gate names are
  not field names outside the seven declared semantic facts. **Recorded, not
  chased.** The 12-static-versus-1-runtime result already showed what happens when
  a measurement limitation is treated as product debt.
