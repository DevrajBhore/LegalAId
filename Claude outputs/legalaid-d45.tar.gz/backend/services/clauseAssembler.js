import { conceptAttaches, resolveConcepts, explainClause } from "./conceptResolver.js";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import Ajv from "ajv";

import { toBlueprintName } from "./documentTypeNormalizer.js";
import { normalizeClauseCategory } from "../config/clauseOrder.js";
import { deriveGenerationControls, isAffirmative, positionOf } from "./generationControls.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const KB_ROOT = path.resolve(__dirname, "../../knowledge-base");
const CLAUSE_LIB = path.join(KB_ROOT, "clause_library");
const BLUEPRINTS = path.join(CLAUSE_LIB, "blueprints");
const CLAUSE_SCHEMA_FILE = path.join(CLAUSE_LIB, "base_clause.schema.json");

let knowledgeBaseCache = null;
let clauseSchemaValidator = null;

function pushUnique(list, value) {
  if (value && !list.includes(value)) {
    list.push(value);
  }
}

function buildBlueprintCandidates(documentType) {
  const base = documentType.toLowerCase();
  const candidates = [];

  pushUnique(candidates, `${toBlueprintName(documentType)}.blueprint.json`);
  pushUnique(candidates, `${base}.blueprint.json`);

  const agreementAlias = base.replace(/_agreement$/, "");
  if (agreementAlias !== base && agreementAlias.split("_").length <= 3) {
    pushUnique(candidates, `${agreementAlias}.blueprint.json`);
  }

  const contractAlias = base.replace(/_contract$/, "");
  if (contractAlias !== base) {
    pushUnique(candidates, `${contractAlias}.blueprint.json`);
  }

  const deedAlias = base.replace(/_deed$/, "");
  if (deedAlias !== base) {
    pushUnique(candidates, `${deedAlias}.blueprint.json`);
  }

  return candidates;
}

function readJsonFile(filePath) {
  try {
    return JSON.parse(fs.readFileSync(filePath, "utf8"));
  } catch (error) {
    throw new Error(`Failed to parse JSON at "${filePath}": ${error.message}`);
  }
}

function extractClauseIds(blueprint, label) {
  // `clauses` is the content of the instrument; `required_clauses` is the subset
  // that must be present. Reading `required_clauses || clauses` meant that once a
  // blueprint declared any required list, everything in `clauses` and not in it
  // was silently dropped -- Terms of Service lost its eligibility, user-content
  // and IP-ownership clauses, and the MSA lost five. Take the union, preserving
  // the order declared in `clauses`.
  const declared = Array.isArray(blueprint.clauses) ? blueprint.clauses : [];
  const required = Array.isArray(blueprint.required_clauses)
    ? blueprint.required_clauses
    : [];
  const clauseIds =
    declared.length || required.length
      ? [...new Set([...declared, ...required])]
      : blueprint.required_clauses || blueprint.clauses || [];

  if (!Array.isArray(clauseIds)) {
    throw new Error(
      `Invalid blueprint format for "${label}": clauses must be an array.`
    );
  }

  for (const clauseId of clauseIds) {
    if (typeof clauseId !== "string" || !clauseId.trim()) {
      throw new Error(
        `Invalid clause reference in "${label}": ${JSON.stringify(clauseId)}`
      );
    }
  }

  return clauseIds;
}

function extractConditionalClauseIds(blueprint, label) {
  const conditionals = blueprint.conditional_clauses || [];

  if (!Array.isArray(conditionals)) {
    throw new Error(
      `Invalid blueprint format for "${label}": conditional_clauses must be an array.`
    );
  }

  const clauseIds = [];
  for (const conditional of conditionals) {
    if (!conditional || typeof conditional !== "object") {
      throw new Error(
        `Invalid conditional clause entry in "${label}": ${JSON.stringify(conditional)}`
      );
    }

    if (typeof conditional.clause !== "string" || !conditional.clause.trim()) {
      throw new Error(
        `Invalid conditional clause reference in "${label}": ${JSON.stringify(conditional)}`
      );
    }

    clauseIds.push(conditional.clause);
  }

  return clauseIds;
}

function extractVariantClauseIds(blueprint, label) {
  const variants = blueprint.variant_clauses || [];

  if (!Array.isArray(variants)) {
    throw new Error(
      `Invalid blueprint format for "${label}": variant_clauses must be an array.`
    );
  }

  const clauseIds = [];
  for (const variant of variants) {
    if (!variant || typeof variant !== "object") {
      throw new Error(
        `Invalid variant clause entry in "${label}": ${JSON.stringify(variant)}`
      );
    }

    const candidates = variant.select_first_match || variant.variants || [];
    if (!Array.isArray(candidates) || candidates.length === 0) {
      throw new Error(
        `Variant slot "${variant.slot || "?"}" in "${label}" must list at least one candidate clause.`
      );
    }

    for (const candidate of candidates) {
      if (typeof candidate?.clause !== "string" || !candidate.clause.trim()) {
        throw new Error(
          `Invalid variant candidate in "${label}" slot "${variant.slot || "?"}": ${JSON.stringify(candidate)}`
        );
      }
      clauseIds.push(candidate.clause);
    }

    if (variant.default) {
      if (typeof variant.default !== "string" || !variant.default.trim()) {
        throw new Error(
          `Invalid default clause for variant slot "${variant.slot || "?"}" in "${label}".`
        );
      }
      clauseIds.push(variant.default);
    }

    if (variant.replaces && typeof variant.replaces !== "string") {
      throw new Error(
        `Invalid "replaces" reference for variant slot "${variant.slot || "?"}" in "${label}".`
      );
    }
  }

  return clauseIds;
}

function extractAllBlueprintClauseIds(blueprint, label) {
  return [
    ...extractClauseIds(blueprint, label),
    ...extractConditionalClauseIds(blueprint, label),
    ...extractVariantClauseIds(blueprint, label),
  ];
}

function chooseVariantClause(variant, variables = {}) {
  const candidates = variant.select_first_match || variant.variants || [];

  for (const candidate of candidates) {
    if (evaluateConditionalExpression(candidate.when ?? candidate.include_if, variables)) {
      return candidate.clause;
    }
  }

  return variant.default || null;
}

function evaluateConditionalExpression(expression, variables = {}) {
  const raw = String(expression || "").trim();
  if (!raw) return false;

  /*
   * `concept:PERSONAL_DATA_PROCESSING` — the clause is governed by a legal
   * concept rather than by a raw intake boolean.
   *
   * The resolutions are computed upstream and passed in under a reserved key, so
   * this evaluator stays a pure function of its inputs and no module has to
   * reach into the knowledge base mid-selection.
   *
   * Reading a concept gate when no resolutions were supplied returns false
   * rather than falling through to `isAffirmative("concept:...")`, which would
   * be false anyway but for the wrong reason and would hide the wiring error.
   */
  if (raw.startsWith("concept:")) {
    const conceptId = raw.slice("concept:".length).trim();
    const resolutions = variables?.__concept_resolutions;
    if (!resolutions || typeof resolutions.get !== "function") return false;
    return conceptAttaches(resolutions.get(conceptId));
  }

  const equalityMatch = raw.match(/^([A-Za-z0-9_]+)\s*(==|!=)\s*(.+)$/);
  if (equalityMatch) {
    const [, variableName, operator, rawExpected] = equalityMatch;
    const actual = variables?.[variableName];
    const expected = rawExpected.trim().replace(/^['"]|['"]$/g, "");

    let result;
    // Three positions, not two. `isAffirmative` collapsed UNKNOWN into FALSE,
    // so a gate could not tell a user who declined a mechanism from a user who
    // was never asked about it, and every blueprint condition silently read
    // silence as refusal. The grammar a blueprint can now express:
    //
    //   x == true      the user affirmatively wants it
    //   x == false     the user affirmatively declined it
    //   x == unknown   the user has not been asked -- the gap check's hook
    //   x != false     include unless declined: the position to use for a
    //                  mechanism the document needs on legal grounds, where
    //                  the user's silence must not defeat it
    //
    // Note this changes `== false`: it now means "declined", not "not affirmed".
    if (/^(true|false|unknown)$/i.test(expected)) {
      result = positionOf(actual) === expected.toUpperCase();
    } else {
      result = String(actual ?? "").trim().toLowerCase() === expected.toLowerCase();
    }

    return operator === "!=" ? !result : result;
  }

  return isAffirmative(variables?.[raw]);
}

function capitalize(text) {
  const value = String(text || "").trim();
  return value ? value.charAt(0).toUpperCase() + value.slice(1) : value;
}

// Resolves the clause ids AND a per-clause "why it's included" reason, so the
// document can explain itself to the user (the explainability feature).
function resolveClauseSelection(blueprint, documentType, variables = {}) {
  const requiredClauseIds = extractClauseIds(blueprint, documentType);
  const conditionals = blueprint.conditional_clauses || [];
  const variants = blueprint.variant_clauses || [];
  const derived = deriveGenerationControls(documentType, variables);
  /*
   * Concepts resolve against the intake answers AND the derived controls,
   * because one legal question is asked under five different names across the
   * portfolio — `involves_personal_data`, `processes_personal_data`, and the
   * `company_`/`firm_`/`jv_` variants — and the derivation is what bridges them.
   * The concept is the single place that question now gets one answer.
   */
  const conceptResolutions = resolveConcepts(variables, derived);
  const resolvedVariables = { ...derived, __concept_resolutions: conceptResolutions };

  const reasons = new Map();
  for (const id of requiredClauseIds) {
    reasons.set(id, "Core clause included in every document of this type.");
  }

  // Apply variant slots: each slot resolves to a single clause chosen by context.
  let clauseIds = [...requiredClauseIds];
  const replacedClauseIds = new Set();
  for (const variant of variants) {
    const chosen = chooseVariantClause(variant, resolvedVariables);
    if (!chosen) continue;

    const replaces = variant.replaces;
    if (replaces && clauseIds.includes(replaces)) {
      if (chosen !== replaces) {
        clauseIds = clauseIds.map((id) => (id === replaces ? chosen : id));
        // Record the swap so later stages (dependencyResolver) don't re-inject the
        // replaced baseline clause via a `required_with`/`depends_on` reference.
        replacedClauseIds.add(replaces);
      }
    } else if (!clauseIds.includes(chosen)) {
      clauseIds.push(chosen);
    }
    reasons.set(
      chosen,
      variant.note ? capitalize(variant.note) : "Selected to match your situation."
    );
  }

  const conditionalClauseIds = conditionals
    .filter((entry) => evaluateConditionalExpression(entry.include_if, resolvedVariables))
    .map((entry) => {
      /*
       * A concept-governed clause explains itself from the law, not from a
       * blueprint note. "Added based on the details you provided" and "personal
       * data is processed, so DPDP Act 2023 s.8(5) applies" are different
       * sentences, and only the second is a reason.
       */
      const explanation = explainClause(entry.clause, conceptResolutions);
      reasons.set(
        entry.clause,
        explanation?.included ? explanation.because
          : entry.note ? capitalize(entry.note) : "Added based on the details you provided."
      );
      return entry.clause;
    });

  const ids = [...new Set([...clauseIds, ...conditionalClauseIds])];

  // CONSIDERED AND EXCLUDED — as distinct from never in play.
  //
  // The dependency resolver could not honour an applicability gate because the
  // gate is not in its scope: it lives in the blueprint, and the resolver
  // receives an assembled clause list. So a clause named in `required_with`
  // was injected whatever the gate had decided, and an unsecured loan carried a
  // security clause.
  //
  // This is the missing information, and ONLY this: a clause whose own
  // `include_if` was evaluated and came out false. It deliberately does NOT
  // include a clause that was variant-replaced (that has its own record), one
  // suppressed by document type, or one that was never a candidate — folding
  // those together would recreate the same ambiguity one layer down, where the
  // resolver could no longer tell "the user declined this" from "this was never
  // on the table".
  //
  // A clause listed BOTH conditionally and unconditionally in one blueprint is
  // not excluded: it survived, so the gate was decorative. Those are a separate
  // defect (27 of them, 20 being CORE_ENTIRE_AGREEMENT_001) and are not this.
  const applicabilityExcludedClauseIds = new Set(
    conditionals
      .filter((entry) => !evaluateConditionalExpression(entry.include_if, resolvedVariables))
      .map((entry) => entry.clause)
      .filter((id) => id && !ids.includes(id))
  );

  return { ids, reasons, replacedClauseIds, applicabilityExcludedClauseIds, conceptResolutions };
}

function getClauseSchemaValidator() {
  if (!clauseSchemaValidator) {
    if (!fs.existsSync(CLAUSE_SCHEMA_FILE)) {
      throw new Error(`Clause schema not found at: ${CLAUSE_SCHEMA_FILE}`);
    }

    const schema = readJsonFile(CLAUSE_SCHEMA_FILE);
    const ajv = new Ajv({ allErrors: true, strict: false });
    clauseSchemaValidator = ajv.compile(schema);
  }

  return clauseSchemaValidator;
}

function loadClauseCache() {
  if (!fs.existsSync(CLAUSE_LIB)) {
    throw new Error(`Clause library not found at: ${CLAUSE_LIB}`);
  }

  const clausesById = new Map();
  const folders = fs.readdirSync(CLAUSE_LIB, { withFileTypes: true });
  const validateClause = getClauseSchemaValidator();

  for (const folder of folders) {
    if (!folder.isDirectory() || folder.name === "blueprints") continue;

    const dir = path.join(CLAUSE_LIB, folder.name);
    const files = fs.readdirSync(dir, { withFileTypes: true });

    for (const file of files) {
      if (!file.isFile() || !file.name.endsWith(".json")) continue;

      const filePath = path.join(dir, file.name);
      const clause = readJsonFile(filePath);

      if (!validateClause(clause)) {
        const details = (validateClause.errors || [])
          .map((error) => `${error.instancePath || "/"} ${error.message}`)
          .join("; ");
        throw new Error(
          `Clause file "${filePath}" failed schema validation: ${details}`
        );
      }

      if (typeof clause?.clause_id !== "string" || !clause.clause_id.trim()) {
        throw new Error(`Clause file "${filePath}" is missing a valid clause_id.`);
      }

      if (typeof clause?.text !== "string" || !clause.text.trim()) {
        throw new Error(`Clause file "${filePath}" is missing clause text.`);
      }

      if (clausesById.has(clause.clause_id)) {
        throw new Error(
          `Duplicate clause_id "${clause.clause_id}" found in "${filePath}".`
        );
      }

      clausesById.set(clause.clause_id, clause);
    }
  }

  if (clausesById.size === 0) {
    throw new Error(`No clause JSON files were loaded from: ${CLAUSE_LIB}`);
  }

  return clausesById;
}

function loadBlueprintCache() {
  if (!fs.existsSync(BLUEPRINTS)) {
    throw new Error(`Blueprint directory not found at: ${BLUEPRINTS}`);
  }

  const blueprintsByFile = new Map();
  const files = fs.readdirSync(BLUEPRINTS, { withFileTypes: true });

  for (const file of files) {
    if (!file.isFile() || !file.name.endsWith(".json")) continue;

    const filePath = path.join(BLUEPRINTS, file.name);
    const blueprint = readJsonFile(filePath);

    extractAllBlueprintClauseIds(blueprint, file.name);
    blueprintsByFile.set(file.name, blueprint);
  }

  if (blueprintsByFile.size === 0) {
    throw new Error(`No blueprint JSON files were loaded from: ${BLUEPRINTS}`);
  }

  return blueprintsByFile;
}

function validateBlueprintReferences(blueprintsByFile, clausesById) {
  const missingReferences = [];

  for (const [fileName, blueprint] of blueprintsByFile.entries()) {
    for (const clauseId of extractAllBlueprintClauseIds(blueprint, fileName)) {
      if (!clausesById.has(clauseId)) {
        missingReferences.push(`${fileName} -> ${clauseId}`);
      }
    }
  }

  if (missingReferences.length > 0) {
    throw new Error(
      "Blueprints reference missing clauses:\n" +
        missingReferences.map((entry) => `- ${entry}`).join("\n")
    );
  }
}

function resolveBlueprint(documentType, blueprintsByFile) {
  const candidates = buildBlueprintCandidates(documentType);

  for (const candidate of candidates) {
    const blueprint = blueprintsByFile.get(candidate);
    if (blueprint) {
      return { blueprint, candidates };
    }
  }

  return { blueprint: null, candidates };
}

function validateDocumentTypeCoverage(blueprintsByFile, documentTypes = []) {
  const missing = [];

  for (const documentType of documentTypes) {
    const { blueprint, candidates } = resolveBlueprint(
      documentType,
      blueprintsByFile
    );

    if (!blueprint) {
      missing.push(`"${documentType}" (tried: ${candidates.join(", ")})`);
    }
  }

  if (missing.length > 0) {
    throw new Error(
      "No blueprint found for configured document types:\n" +
        missing.map((entry) => `- ${entry}`).join("\n")
    );
  }
}

function getKnowledgeBaseCache() {
  if (!knowledgeBaseCache) {
    preloadKnowledgeBase();
  }

  return knowledgeBaseCache;
}

export function preloadKnowledgeBase({ documentTypes = [] } = {}) {
  if (!knowledgeBaseCache) {
    const clausesById = loadClauseCache();
    const blueprintsByFile = loadBlueprintCache();

    validateBlueprintReferences(blueprintsByFile, clausesById);
    validateDocumentTypeCoverage(blueprintsByFile, documentTypes);

    knowledgeBaseCache = {
      clausesById,
      blueprintsByFile,
      stats: {
        clauseCount: clausesById.size,
        blueprintCount: blueprintsByFile.size,
        documentTypeCount: documentTypes.length,
      },
    };
  } else if (documentTypes.length > 0) {
    validateDocumentTypeCoverage(knowledgeBaseCache.blueprintsByFile, documentTypes);
  }

  return knowledgeBaseCache.stats;
}

export function assembleDocument(documentType, variables = {}) {
  const { clausesById, blueprintsByFile } = getKnowledgeBaseCache();
  const { blueprint, candidates } = resolveBlueprint(
    documentType,
    blueprintsByFile
  );

  if (!blueprint) {
    throw new Error(
      `Blueprint not found for document type: "${documentType}". ` +
        `Tried: ${candidates.join(", ")}`
    );
  }

  const { ids: clauseIds, reasons, replacedClauseIds, applicabilityExcludedClauseIds,
    conceptResolutions } = resolveClauseSelection(
    blueprint,
    documentType,
    variables
  );
  const clauseProvenance = {};
  const clauses = clauseIds.map((id, index) => {
    const clause = clausesById.get(id);
    if (!clause) {
      throw new Error(
        `Clause "${id}" referenced by "${documentType}" was not found in the preloaded cache.`
      );
    }
    const reason = reasons.get(id) || "Core clause for this document type.";
    // Per-clause provenance so the editor can explain "why this clause" and
    // "which Indian law backs it". Stored in metadata so it survives the
    // generation/AI pipeline even if clause text is rewritten.
    const explanation = explainClause(id, conceptResolutions);
    clauseProvenance[id] = {
      reason,
      /*
       * The concept's authority, kept SEPARATE from the clause's own
       * legal_basis. They answer different questions: legal_basis is what this
       * clause is drafted under, concept_authority is why this transaction
       * needed a clause of this kind at all. Merging them would let a clause
       * that cites a statute look as though its APPLICABILITY had been
       * established, which is the conflation the trace was built to expose.
       */
      concept: explanation?.concept || null,
      concept_authority: explanation?.included ? explanation.authority : null,
      concept_provenance: explanation?.included ? explanation.provenance : null,
      legal_basis: clause.legal_basis || [],
      name: clause.title || clause.name || id,
      category: normalizeClauseCategory(clause.category),
    };
    return {
      ...clause,
      category: normalizeClauseCategory(clause.category),
      title: clause.title || clause.name || null,
      inclusion_reason: reason,
      blueprint_position: index + 1,
    };
  });

  return {
    document_type: documentType,
    jurisdiction: "India",
    clauses,
    metadata: {
      blueprint_clause_count: clauseIds.length,
      loaded_clause_count: clauses.length,
      missing_clauses: [],
      clause_provenance: clauseProvenance,
      resolved_generation_controls: deriveGenerationControls(documentType, variables),
      /*
       * Every concept the repository holds, resolved for this document —
       * including the ones that came out ABSENT. "Why isn't this clause here?"
       * needs the negative resolutions as much as the positive ones, and an
       * absent concept that went unrecorded is indistinguishable from a concept
       * nobody considered.
       */
      concept_resolutions: [...conceptResolutions.values()].map((r) => ({
        concept_id: r.concept_id, state: r.state, provenance: r.provenance,
        assumed: r.assumed, disclose: r.disclose,
        authority: r.authority, attaches: r.attaches,
        evidence: r.evidence, review_status: r.review_status,
      })),
      variant_replaced_clause_ids: [...replacedClauseIds],
      // Always written when selection runs, so that ABSENT and EMPTY are
      // different facts downstream: empty means the gates excluded nothing,
      // absent means nobody evaluated any gate. A conditional dependency may
      // not read the second as the first.
      applicability_excluded_clause_ids: [...applicabilityExcludedClauseIds],
    },
  };
}

export function getKnowledgeBaseStats() {
  return getKnowledgeBaseCache().stats;
}

// The resolved blueprint object for a document type (required/conditional/variant
// clauses). Exposed so the revision layer can derive concept→variable levers from
// the SAME blueprint the assembler uses — single source, no drift.
export function getBlueprintForDocumentType(documentType) {
  const { blueprintsByFile } = getKnowledgeBaseCache();
  const { blueprint } = resolveBlueprint(documentType, blueprintsByFile);
  return blueprint || null;
}

export function getClauseById(clauseId) {
  if (!clauseId) return null;
  return getKnowledgeBaseCache().clausesById.get(clauseId) || null;
}

export function getAllClauses() {
  return [...getKnowledgeBaseCache().clausesById.values()];
}

export function clearClauseCache() {
  knowledgeBaseCache = null;
}
