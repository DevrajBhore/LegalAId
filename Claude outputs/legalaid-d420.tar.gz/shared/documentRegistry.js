import { knowledgeRegistryEntries } from "./knowledgeDocuments.js";

const CODE_DEFINED_REGISTRY = {
  FOUNDERS_AGREEMENT: {
    displayName: "Founders' Agreement",
    family: "Startup & Fundraising",
    ireType: "FOUNDERS_AGREEMENT",
    blueprintName: "founders_agreement",
  },
  TERM_SHEET: {
    displayName: "Term Sheet",
    family: "Startup & Fundraising",
    ireType: "TERM_SHEET",
    blueprintName: "term_sheet",
  },
  ESOP_GRANT_LETTER: {
    displayName: "ESOP Grant Letter",
    family: "Startup & Fundraising",
    ireType: "ESOP_GRANT_LETTER",
    blueprintName: "esop_grant_letter",
  },
  SHARE_SUBSCRIPTION_AGREEMENT: {
    displayName: "Share Subscription Agreement",
    family: "Startup & Fundraising",
    ireType: "SHARE_SUBSCRIPTION_AGREEMENT",
    blueprintName: "share_subscription_agreement",
  },

  PROMISSORY_NOTE: {
    displayName: "Promissory Note",
    family: "Finance",
    ireType: "PROMISSORY_NOTE",
    blueprintName: "promissory_note",
  },
  IP_ASSIGNMENT_AGREEMENT: {
    displayName: "IP Assignment Agreement",
    family: "Intellectual Property",
    ireType: "IP_ASSIGNMENT_AGREEMENT",
    blueprintName: "ip_assignment_agreement",
  },
  POWER_OF_ATTORNEY: {
    displayName: "Power of Attorney",
    family: "Instruments",
    ireType: "POWER_OF_ATTORNEY",
    blueprintName: "power_of_attorney",
  },

  DATA_PROCESSING_AGREEMENT: {
    displayName: "Data Processing Agreement",
    family: "Data & Compliance",
    ireType: "DATA_PROCESSING_AGREEMENT",
    blueprintName: "data_processing_agreement",
  },
  REFUND_AND_CANCELLATION_POLICY: {
    displayName: "Refund & Cancellation Policy",
    family: "Data & Compliance",
    ireType: "REFUND_AND_CANCELLATION_POLICY",
    blueprintName: "refund_and_cancellation_policy",
  },
  SHIPPING_AND_DELIVERY_POLICY: {
    displayName: "Shipping & Delivery Policy",
    family: "Data & Compliance",
    ireType: "SHIPPING_AND_DELIVERY_POLICY",
    blueprintName: "shipping_and_delivery_policy",
  },

  APPOINTMENT_LETTER: {
    displayName: "Appointment Letter",
    family: "Employment",
    ireType: "APPOINTMENT_LETTER",
    blueprintName: "appointment_letter",
  },
  INTERNSHIP_AGREEMENT: {
    displayName: "Internship Agreement",
    family: "Employment",
    ireType: "INTERNSHIP_AGREEMENT",
    blueprintName: "internship_agreement",
  },
  SEPARATION_AGREEMENT: {
    displayName: "Separation & Full and Final Settlement",
    family: "Employment",
    ireType: "SEPARATION_AGREEMENT",
    blueprintName: "separation_agreement",
  },
  POSH_POLICY: {
    displayName: "PoSH Policy",
    family: "Employment",
    ireType: "POSH_POLICY",
    blueprintName: "posh_policy",
  },

  // ─── Notices and dispute instruments ──────────────────────────────────────
  // LEGAL_NOTICE, REPLY_TO_LEGAL_NOTICE and CHEQUE_BOUNCE_NOTICE are built and
  // tested but deliberately NOT offered yet. Their clauses, blueprints, intake
  // fields and the Section 138 deadline arithmetic all remain in place; only
  // these registry entries were removed, which is what the product reads. To
  // bring one back, restore its entry here and drop the _unreachable flag from
  // its blueprint.
  ARBITRATION_NOTICE: {
    displayName: "Arbitration Notice (S.21)",
    family: "Notices & Disputes",
    ireType: "ARBITRATION_NOTICE",
    blueprintName: "arbitration_notice",
  },
  SETTLEMENT_AGREEMENT: {
    displayName: "Settlement Agreement",
    family: "Notices & Disputes",
    ireType: "SETTLEMENT_AGREEMENT",
    blueprintName: "settlement_agreement",
  },
  AFFIDAVIT: {
    displayName: "Affidavit",
    family: "Notices & Disputes",
    ireType: "AFFIDAVIT",
    blueprintName: "affidavit",
  },
  INDEMNITY_BOND: {
    displayName: "Indemnity Bond",
    family: "Notices & Disputes",
    ireType: "INDEMNITY_BOND",
    blueprintName: "indemnity_bond",
  },

  NDA: {
    displayName: "Non-Disclosure Agreement",
    family: "Contracts & Commercial",
    ireType: "NDA",
    blueprintName: "nda",
  },
  EMPLOYMENT_CONTRACT: {
    displayName: "Employment Contract",
    family: "Employment",
    ireType: "EMPLOYMENT_AGREEMENT",
    blueprintName: "employment_contract",
  },
  SERVICE_AGREEMENT: {
    displayName: "Service Agreement",
    family: "Contracts & Commercial",
    ireType: "SERVICE_AGREEMENT",
    blueprintName: "service",
  },
  CONSULTANCY_AGREEMENT: {
    displayName: "Consultancy Agreement",
    family: "Contracts & Commercial",
    ireType: "CONSULTANCY_AGREEMENT",
    blueprintName: "consultancy_agreement",
  },
  PARTNERSHIP_DEED: {
    displayName: "Partnership Deed",
    family: "Corporate",
    ireType: "PARTNERSHIP_DEED",
    blueprintName: "partnership_deed",
  },
  SHAREHOLDERS_AGREEMENT: {
    displayName: "Shareholders Agreement",
    family: "Corporate",
    ireType: "SHAREHOLDERS_AGREEMENT",
    blueprintName: "shareholders_agreement",
  },
  JOINT_VENTURE_AGREEMENT: {
    displayName: "Joint Venture Agreement",
    family: "Corporate",
    ireType: "JOINT_VENTURE_AGREEMENT",
    blueprintName: "joint_venture_agreement",
  },
  SUPPLY_AGREEMENT: {
    displayName: "Supply Agreement",
    family: "Contracts & Commercial",
    ireType: "SUPPLY_AGREEMENT",
    blueprintName: "supply_agreement",
  },
  DISTRIBUTION_AGREEMENT: {
    displayName: "Distribution Agreement",
    family: "Contracts & Commercial",
    ireType: "DISTRIBUTION_AGREEMENT",
    blueprintName: "distribution_agreement",
  },
  SALES_OF_GOODS_AGREEMENT: {
    displayName: "Sale of Goods Agreement",
    family: "Contracts & Commercial",
    ireType: "SALES_OF_GOODS_AGREEMENT",
    blueprintName: "sales_of_goods_agreement",
  },
  INDEPENDENT_CONTRACTOR_AGREEMENT: {
    displayName: "Independent Contractor Agreement",
    family: "Contracts & Commercial",
    ireType: "INDEPENDENT_CONTRACTOR_AGREEMENT",
    blueprintName: "independent_contractor_agreement",
  },
  COMMERCIAL_LEASE_AGREEMENT: {
    displayName: "Commercial Lease Agreement",
    family: "Property",
    ireType: "COMMERCIAL_LEASE_AGREEMENT",
    blueprintName: "commercial_lease_agreement",
  },
  LEAVE_AND_LICENSE_AGREEMENT: {
    displayName: "Leave and License Agreement",
    family: "Property",
    ireType: "LEAVE_AND_LICENSE_AGREEMENT",
    blueprintName: "leave_and_license_agreement",
  },
  LOAN_AGREEMENT: {
    displayName: "Loan Agreement",
    family: "Finance",
    ireType: "LOAN_AGREEMENT",
    blueprintName: "loan",
  },
  GUARANTEE_AGREEMENT: {
    displayName: "Guarantee Agreement",
    family: "Finance",
    ireType: "GUARANTEE_AGREEMENT",
    blueprintName: "guarantee",
  },
  SOFTWARE_DEVELOPMENT_AGREEMENT: {
    displayName: "Software Development Agreement",
    family: "Contracts & Commercial",
    ireType: "SOFTWARE_DEVELOPMENT_AGREEMENT",
    blueprintName: "technology",
  },
  MOU: {
    displayName: "Memorandum of Understanding",
    family: "Corporate",
    ireType: "MOU",
    blueprintName: "mou",
  },
  VENDOR_AGREEMENT: {
    displayName: "Vendor Agreement",
    family: "Contracts & Commercial",
    ireType: "VENDOR_AGREEMENT",
    blueprintName: "vendor",
  },
  MASTER_SERVICE_AGREEMENT: {
    displayName: "Master Service Agreement",
    family: "Contracts & Commercial",
    ireType: "MASTER_SERVICE_AGREEMENT",
    blueprintName: "msa",
  },
  TERMS_OF_SERVICE: {
    displayName: "Terms of Service",
    family: "Contracts & Commercial",
    ireType: "TERMS_OF_SERVICE",
    blueprintName: "tos",
  },
  // The startup invariant in backend/index.js asserts DOCUMENT_CONFIG ⊆ this
  // registry — the registry is allowed to stage types ahead of config, but
  // config may never reference a type that is missing here.
  PRIVACY_POLICY: {
    displayName: "Privacy Policy",
    family: "Contracts & Commercial",
    ireType: "PRIVACY_POLICY",
    blueprintName: "privacy",
  },
  RENTAL_AGREEMENT: {
    displayName: "Rental Agreement",
    family: "Property",
    ireType: "RENTAL_AGREEMENT",
    blueprintName: "rental",
  },
};

export const DOCUMENT_TYPE_ALIASES = {
  EMPLOYMENT_AGREEMENT: "EMPLOYMENT_CONTRACT",
  SERVICE_PROVIDER_AGREEMENT: "SERVICE_AGREEMENT",
  INDEPENDENT_CONTRACTOR: "INDEPENDENT_CONTRACTOR_AGREEMENT",
  LEAVE_AND_LICENSE: "LEAVE_AND_LICENSE_AGREEMENT",
  ADDENDUM: "SERVICE_AGREEMENT",
  Rental: "RENTAL_AGREEMENT",
  Employment: "EMPLOYMENT_CONTRACT",
  Service: "SERVICE_AGREEMENT",
  PrivacyPolicy: "PRIVACY_POLICY",
  MSA: "MASTER_SERVICE_AGREEMENT",
  TOS: "TERMS_OF_SERVICE",
  TERMS_OF_USE: "TERMS_OF_SERVICE",
  TermsOfService: "TERMS_OF_SERVICE",
};

function prettifyDocumentType(type) {
  return (type || "LEGAL DOCUMENT")
    .replace(/_/g, " ")
    .split(" ")
    .filter(Boolean)
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(" ");
}

export function getCanonicalDocumentType(type) {
  if (typeof type !== "string") return type;
  return DOCUMENT_TYPE_ALIASES[type] || type;
}

export function getDocumentTypeMeta(type) {
  const canonicalType = getCanonicalDocumentType(type);
  return DOCUMENT_TYPE_REGISTRY[canonicalType] || null;
}

export function getDocumentDisplayName(type) {
  return getDocumentTypeMeta(type)?.displayName || prettifyDocumentType(type);
}

export function getDocumentFamily(type) {
  return getDocumentTypeMeta(type)?.family || "Other";
}

export function toIREDocType(type) {
  const canonicalType = getCanonicalDocumentType(type);
  return getDocumentTypeMeta(canonicalType)?.ireType || canonicalType;
}

export function toBlueprintName(type) {
  const canonicalType = getCanonicalDocumentType(type);
  return (
    getDocumentTypeMeta(canonicalType)?.blueprintName ||
    (typeof canonicalType === "string" ? canonicalType.toLowerCase() : "")
  );
}

export function buildDocumentTypeMeta(type) {
  const canonicalType = getCanonicalDocumentType(type);
  return {
    type: canonicalType,
    displayName: getDocumentDisplayName(canonicalType),
    family: getDocumentFamily(canonicalType),
    ireType: toIREDocType(canonicalType),
    blueprintName: toBlueprintName(canonicalType),
  };
}

// Families defined in the knowledge base are discovered, not registered. The
// engine asks what definitions exist; it is never told. The block above is the
// forty families still defined in code -- debt to be migrated, not the design.
export const DOCUMENT_TYPE_REGISTRY = {
  ...CODE_DEFINED_REGISTRY,
  ...knowledgeRegistryEntries(),
};
