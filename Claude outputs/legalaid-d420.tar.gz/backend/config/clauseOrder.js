const CANONICAL_ORDER = [
  "IDENTITY",
  "RECITALS",
  "PURPOSE",
  // A notice runs in its own order and shares none of the agreement categories,
  // so these sit together near the top where a notice's identity block leaves
  // off. An agreement never carries one of them, and a notice never carries the
  // agreement categories below.
  "NOTICE_HEADING",
  "NOTICE_FACTS",
  "NOTICE_BREACH",
  "NOTICE_DEMAND",
  "NOTICE_DEADLINE",
  "NOTICE_CONSEQUENCE",
  "NOTICE_RESERVATION",
  // A sworn or unilateral instrument: the statement of facts, then the
  // statement of truth that makes it an affidavit rather than a letter.
  "DEPOSITION",
  "STATEMENT_OF_TRUTH",
  "INDEMNITY_COVENANT",
  "DEFINITIONS",
  "INTERPRETATION",
  "RELATIONSHIP",
  "FORMATION",
  "EMPLOYMENT",
  "CONSIDERATION",
  "PAYMENT",
  "FINANCE",
  "DELIVERY",
  "SERVICE",
  "SUPPLY",
  "TIMELINE",
  "SLA",
  "ACCEPTANCE",
  "INSPECTION",
  "QUALITY",
  "REJECTION",
  "SHORTAGE",
  "CHANGE",
  // A release of claims discharges what the consideration has just bought,
  // so it follows the settlement and precedes the obligations that survive it.
  "RELEASE",
  "OBLIGATIONS",
  "CONFIDENTIALITY",
  "EXCLUSIONS",
  "PRIVACY",
  "DATA_PROCESSING",
  "IP",
  "INTELLECTUAL_PROPERTY",
  "WARRANTY",
  "REPRESENTATIONS",
  "REGULATORY",
  "COMPLIANCE",
  // Audit, information and escalation rights. They sit after the compliance
  // obligations they verify and before the corporate and property provisions,
  // which is where a reader looks for the machinery that checks performance.
  "GOVERNANCE",
  "CORPORATE",
  "PROPERTY",
  "PROCEDURAL",
  "RESTRAINT",
  "REMEDIES",
  "RISK",
  "LIABILITY",
  "INDEMNITY",
  "ENFORCEABILITY",
  // Insurance sits with the other risk-transfer provisions, after liability and
  // indemnity have defined what each party bears.
  "INSURANCE",
  "EXPENSES",
  "TERM",
  "FORCE_MAJEURE",
  "SURVIVAL",
  "TERMINATION",
  "TERMINATION_NOTICE",
  "NOTICE",
  "ASSIGNMENT",
  "AMENDMENT",
  "WAIVER",
  "SEVERABILITY",
  "ENTIRE_AGREEMENT",
  "FURTHER_ASSURANCE",
  "COUNTERPARTS",
  "ARBITRATION",
  "DISPUTE",
  "DISPUTE_RESOLUTION",
  "JURISDICTION",
  "GOVERNING_LAW",
  "SCHEDULE",
  "ANNEXURE",
  "SPECIFICATIONS",
  "EXECUTION_FORMALITIES",
  "EXECUTION",
  "SIGNATURE_BLOCK",
];

const CATEGORY_ALIASES = {
  CONTRACT: "FORMATION",
  NDA: "CONFIDENTIALITY",
  NOTICES: "NOTICE",
  TERMINATION_NOTICE: "TERMINATION_NOTICE",
  INDEMNIFICATION: "INDEMNITY",
  LIABILITY_CAP: "RISK",
  LIABILITY_LIMITATION: "RISK",
  ANNEX: "ANNEXURE",
  APPENDIX: "ANNEXURE",
  SPECIFICATION: "SPECIFICATIONS",
  MATERIALS: "SPECIFICATIONS",
  SCHEDULES: "SCHEDULE",
};

export const CLAUSE_ORDER = [...CANONICAL_ORDER];

const ORDER_MAP = new Map(CANONICAL_ORDER.map((category, index) => [category, index]));

export function normalizeClauseCategory(category = "") {
  const normalized = String(category || "")
    .trim()
    .replace(/[^a-zA-Z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "")
    .toUpperCase();

  return CATEGORY_ALIASES[normalized] || normalized;
}

function getClauseOrderIndex(category) {
  const normalized = normalizeClauseCategory(category);
  const signatureIndex = ORDER_MAP.get("SIGNATURE_BLOCK") ?? 999;
  return ORDER_MAP.get(normalized) ?? signatureIndex - 1;
}

export function sortClausesByOrder(clauses = []) {
  return [...clauses].sort((left, right) => {
    const leftIndex = getClauseOrderIndex(left?.category);
    const rightIndex = getClauseOrderIndex(right?.category);

    if (leftIndex !== rightIndex) {
      return leftIndex - rightIndex;
    }

    const leftBlueprintPosition = Number(left?.blueprint_position);
    const rightBlueprintPosition = Number(right?.blueprint_position);
    const leftHasBlueprintPosition = Number.isFinite(leftBlueprintPosition);
    const rightHasBlueprintPosition = Number.isFinite(rightBlueprintPosition);

    if (
      leftHasBlueprintPosition &&
      rightHasBlueprintPosition &&
      leftBlueprintPosition !== rightBlueprintPosition
    ) {
      return leftBlueprintPosition - rightBlueprintPosition;
    }

    if (leftHasBlueprintPosition !== rightHasBlueprintPosition) {
      return leftHasBlueprintPosition ? -1 : 1;
    }

    const leftTitle = String(left?.title || left?.clause_id || "");
    const rightTitle = String(right?.title || right?.clause_id || "");
    return leftTitle.localeCompare(rightTitle);
  });
}
