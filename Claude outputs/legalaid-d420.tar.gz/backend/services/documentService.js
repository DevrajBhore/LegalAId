import path from "path";
import { fileURLToPath, pathToFileURL } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const IRE_ROOT = path.resolve(__dirname, "../../IRE");

export const GENERATION_GUARDRAIL_BUILD = "identity-guardrails-2026-08-16";

import { injectDoctrine } from "./doctrineInjector.js";
import { enforceScopeGuard } from "./scopeGuard.js";
import { resolveSignatures } from "./signatureResolver.js";
import { assembleDocument } from "./clauseAssembler.js";
import { injectDraftVariables } from "./draftVariableInjector.js";
import { sanitizeVariablesForDocument } from "../config/variableConfig.js";
import { loadVariables } from "./variableLoader.js";
import { validateVariables } from "./variableValidator.js";
import { applyDeterministicFixes } from "./deterministicFixer.js";
import { enhanceCommercially } from "../commercial/commercialEngine.js";
import { normalizeClauseText } from "./clauseQualityNormalizer.js";
import { lockCriticalClauses } from "./clauseLocker.js";
import { resolveDependencies } from "./dependencyResolver.js";
import { injectJurisdictionRules } from "./jurisdictionEngine.js";
import { applyDocumentHardening } from "./documentHardening.js";
import { applyDocumentQualityControls } from "./documentQualityControl.js";
import {
  formatValidationResult,
  runDocumentValidation,
} from "./validationService.js";
import { callAI } from "../ai/aiClient.js";
import { deriveGenerationControls } from "./generationControls.js";
import { buildSemanticContext } from "./inputSemantics.js";
import { buildDocumentIntelligence } from "./documentIntelligence.js";
import { resolvePositions } from "./positionResolution.js";
import { assessRequirements } from "./documentRequirements.js";
import { resolveCanonicalFacts } from "./canonicalFacts.js";
import { getVariables } from "../config/variableConfig.js";
import { buildObligations } from "./obligationTracker.js";
import { resolveStampFinancials } from "./stampDutyBasis.js";
import { resolveRoster } from "./partyRoster.js";
import { unresolvedTreatments } from "./npartyTreatment.js";
import { resolveAllocations } from "./economicAllocation.js";

// Attach the advisory risk-&-explainability report + lifecycle obligations to a
// successful generation.
// A position is a boolean; the intake schema speaks in the words its own select
// offers. Writing `true` into a field whose options are "AI Recommended / Yes /
// No" fails validation and blocks the draft, so a resolved position is spoken
// back in the field's own vocabulary where the field exists, and left as a
// boolean where it is a pure derivation with no field behind it.
function serialisePositions(documentType, positions = {}) {
  let schema = {};
  try {
    schema = getVariables(documentType) || {};
  } catch {
    schema = {};
  }
  const out = {};
  for (const [flag, position] of Object.entries(positions)) {
    const options = schema[flag]?.options;
    if (typeof position.value === "boolean" && Array.isArray(options)) {
      const wanted = position.value ? "yes" : "no";
      const match = options.find((option) => String(option).trim().toLowerCase() === wanted);
      out[flag] = match ?? position.value;
      continue;
    }
    out[flag] = position.value;
  }
  return out;
}

function buildRosterDisclosure(variables = {}) {
  const roster = resolveRoster(variables);
  return {
    count: roster.count,
    source: roster.source,
    prefix: roster.prefix,
    members: (roster.members || []).map((m) => ({ index: m.index, name: m.name })),
    gaps: roster.gaps || [],
    duplicates: roster.duplicates || [],
    merged: roster.merged || [],
    conflicts: roster.conflicts || [],
    reconciled: roster.reconciled !== false,
    multi_party: roster.count > 2,
  };
}

// The N-party points this document leaves open, for disclosure to the reader.
//
// Read from the clauses AS SHIPPED rather than from the blueprint: a clause the
// document did not take cannot leave anything open in it, and a clause a builder
// added at generation time can. D4.15 measured that difference and it was 23
// clauses against 17.
function buildOpenTreatments(draft, variables = {}) {
  const roster = resolveRoster(variables);
  if (!(roster.count > 2)) return [];

  return unresolvedTreatments(
    (draft?.clauses || []).map((clause) => clause.clause_id).filter(Boolean),
    roster.count
  ).map((treatment) => ({
    clause_id: treatment.clause_id,
    // TWO DIFFERENT KINDS OF NOT-KNOWING, AND MERGING THEM HIDES THE SMALLER ONE.
    //
    // A clause classified into a decision-requiring shape has an identified
    // legal question with authored candidate readings and nobody has chosen --
    // six of these, and they are what an advocate reviews. A clause that was
    // never examined for N-party behaviour at all is also unresolved, and
    // deliberately so (an unclassified clause is not thereby safe to
    // pluralise), but it is a gap in the classification rather than an open
    // question of law. Reported side by side and labelled, because twenty of
    // the second kind would otherwise bury two of the first.
    kind: treatment.shape ? "AUTHORED_DECISION_PENDING" : "NOT_CLASSIFIED",
    decision_id: treatment.decision_id || null,
    shape: treatment.shape || null,
    // UNDECIDED, and the field says so rather than omitting itself. A missing
    // key reads as "nothing to see"; the word is the finding.
    decision: treatment.shape ? treatment.decision || "UNDECIDED" : null,
    legal_question: treatment.legal_question || null,
    candidate_treatments: treatment.candidates || [],
    party_count: roster.count,
    why: treatment.why,
  }));
}

function buildSuccess(draft, validation, resolution = null, options = {}) {
  const variables = draft?.metadata?.source_variables || {};
  const markedDraft = {
    ...draft,
    metadata: {
      ...(draft?.metadata || {}),
      generation_guardrail_build: GENERATION_GUARDRAIL_BUILD,
      // Carried on the draft itself, not only on the API response, so whatever
      // renders the document can put these in front of the reader. NOTE: the
      // DOCX, PDF and text exporters do not yet print them -- a disclosure that
      // appears in the app but not in the file the user signs is worth less than
      // none, so that is a deliberate next step rather than a half-done one.
      assumptions: resolution?.assumptions || [],
    },
  };

  // The resolution computed upstream in prepareGenerationInput, carried here
  // rather than recomputed. Falls back to resolving only where a draft reached
  // this function without having gone through generation preparation (repair
  // and revision paths), and that fallback is itself the same function.
  const canonicalFacts = options?.canonicalFacts || resolveCanonicalFacts(
    draft?.document_type, variables, resolution?.positions || {}
  );

  return {
    draft: markedDraft,
    validation,
    intelligence: buildDocumentIntelligence(markedDraft, validation),
    obligations: buildObligations(draft, variables),
    // What this document assumes, and what it still does not settle. Written so
    // a reader can act on it: every entry says what was not decided and who did
    // not decide it, and none of them claims the user chose.
    assumptions: resolution?.assumptions || [],
    position_outcomes: resolution?.outcomes || [],
    // Does this document do what this KIND of document has to do? Reported
    // separately from the clause count, because a draft can carry forty
    // well-drafted boilerplate clauses and still fail to be the instrument it
    // claims to be. Boilerplate coverage must never stand in for identity.
    // ONE resolution, consumed by both halves. Assessment used to read
    // resolution.positions while clause selection read the derived controls, so
    // a requirement conditioned on a derived fact reported
    // APPLICABILITY_UNKNOWN while the document shipped the clause that fact had
    // gated. Nine of nine conditional requirements, across three families.
    canonical_facts: canonicalFacts.outcomes,
    // ── What this instrument does not settle, because more than two people
    //    signed it ──────────────────────────────────────────────────────────
    //
    // Party cardinality and legal interpretation are independent dimensions,
    // and this field is where that independence becomes visible. A deed with
    // three partners generates: every principal is named, bound and signed for.
    // It also arrives carrying the points its own clauses leave open, because
    // "the aggregate liability of either Party shall not exceed X" has three
    // readings at three parties that differ in money, and choosing one of them
    // is deciding a question of law while calling it a rendering detail.
    //
    // Empty for every two-party document, where the readings coincide. Never a
    // reason to withhold the draft -- the user gets the instrument AND the list
    // of what an advocate still has to settle in it.
    open_treatments: buildOpenTreatments(draft, variables),
    // WHO THIS INSTRUMENT IS ABOUT, AS THE ENGINE RESOLVED IT.
    //
    // Reported next to the draft so the answer can be checked against the
    // document rather than inferred from it. `gaps` says a slot was left empty
    // and the principals after it were kept where the user put them; `merged`
    // and `duplicates` say two descriptions turned out to be one person;
    // `conflicts` says somebody was named that the authoritative collection does
    // not contain, which is the one state where the roster declines to decide.
    party_roster: buildRosterDisclosure(variables),
    // ── Which party gets which share ─────────────────────────────────────
    //
    // Reported per allocation, with the state named rather than reduced to a
    // boolean: ROSTER_ADDRESSED means every share is attached to a party the
    // instrument binds; UNATTRIBUTED means shares were written and nothing says
    // whose; CONFLICT means a share is written against somebody who is not a
    // party. Nothing here is rescaled or reordered on the way out.
    allocations: resolveAllocations(draft?.document_type, variables),
    requirements: assessRequirements(
      draft?.document_type,
      (draft?.clauses || []).map((clause) => clause.clause_id),
      canonicalFacts.facts,
      variables,
      [],
      // The clauses AS RENDERED, not as they sit in the library. A relationship
      // between two clauses is a question about the words the reader will
      // actually see, and those words carry this document's own substitutions.
      // Assessing library text would answer the question about a document
      // nobody received.
      Object.fromEntries(
        (draft?.clauses || []).map((clause) => [clause.clause_id, clause.text || ""])
      )
    ),
  };
}

let CategoryMapper = null;

async function loadIREModules() {
  if (CategoryMapper) return;

  try {
    const cmPath = pathToFileURL(
      path.join(IRE_ROOT, "src/indian-rule-engine/CategoryMapper.js")
    ).href;
    const cm = await import(cmPath);
    CategoryMapper = cm;
  } catch (err) {
    console.warn(
      "[DocumentService] Could not load IRE modules directly:",
      err.message
    );
    CategoryMapper = { mapAndNormalize: (draft) => draft };
  }
}

function validateInputByDocumentType(input) {
  const schema = loadVariables(input.document_type);
  const sanitizedVariables = sanitizeVariablesForDocument(
    input.document_type,
    input.variables || {}
  );
  const errors = validateVariables(schema, sanitizedVariables, {
    documentType: input.document_type,
    mode: input.mode,
  });
  return errors.length > 0 ? { valid: false, errors } : { valid: true };
}

function prepareGenerationInput(input = {}) {
  const sanitizedVariables = sanitizeVariablesForDocument(
    input.document_type,
    input.variables || {}
  );

  // ONE CANONICAL VALUE, BEFORE ANY CONSUMER.
  //
  // Resolved here — upstream of the derivation, upstream of clause selection,
  // upstream of assessment — and overlaid onto the variables everything
  // downstream reads. Both halves of the system therefore consume the same
  // object rather than two normalisations that happen to agree.
  //
  // They did happen to agree: a select's own word reached clause selection as
  // "Yes" and assessment as true, and both were right because both called
  // positionOf. Two call sites of the same function is not one value; it is two
  // values that are currently equal. The next gate written against the raw cell
  // — or the next normaliser that handles "Y" differently — makes them differ,
  // silently, in the direction where the document acts and the report does not.
  const canonical = resolveCanonicalFacts(
    input.document_type,
    sanitizedVariables,
    sanitizedVariables.__resolved_positions || {}
  );
  const variables = deriveGenerationControls(input.document_type, {
    ...sanitizedVariables,
    ...canonical.values,
  });

  return {
    ...input,
    variables,
    // Carried, not recomputed downstream. buildSuccess used to resolve the facts
    // a second time from the draft's source_variables; equal inputs made equal
    // answers, but "resolved twice and compared" is the shape of the defect this
    // whole phase exists to remove.
    canonicalFacts: canonical,
    semanticContext: buildSemanticContext(input.document_type, variables),
  };
}

function buildBlockedGenerationResult(issues, { statusCode = 422, error } = {}) {
  const validation = formatValidationResult({
    mode: "generation",
    issues,
    risk: "BLOCKED",
    certified: false,
  });
  const latestIssue =
    issues?.[0]?.message ||
    validation?.blockingIssues?.[0]?.message ||
    validation?.advisoryIssues?.[0]?.message;

  return {
    draft: null,
    validation,
    statusCode,
    error:
      error ||
      latestIssue ||
      "We couldn't generate a valid first draft from the supplied inputs.",
  };
}

function createBlueprintDraft(input) {
  return assembleDocument(input.document_type, input.variables);
}

function createDeterministicBaseDraft(input) {
  return injectDraftVariables(createBlueprintDraft(input), input.variables);
}

function sanitizeSourceVariables(variables = {}) {
  return Object.fromEntries(
    Object.entries(variables || {}).filter(
      ([, value]) => value !== undefined && value !== null && value !== ""
    )
  );
}

function buildBaselineClauseMap(clauses = []) {
  return Object.fromEntries(
    (clauses || [])
      .filter((clause) => clause?.clause_id)
      .map((clause) => [
        clause.clause_id,
        {
          clause_id: clause.clause_id,
          title: clause.title || null,
          category: clause.category || null,
          text: clause.text || "",
        },
      ])
  );
}

function attachDraftContext(draft, input, { resetBaseline = false } = {}) {
  const existingBaseline = draft?.metadata?.baseline_clause_map;

  return {
    ...draft,
    document_type: input.document_type,
    jurisdiction: input.jurisdiction || draft?.jurisdiction || "India",
    metadata: {
      ...(draft?.metadata || {}),
      document_type: input.document_type,
      jurisdiction: input.jurisdiction || draft?.jurisdiction || "India",
      source_variables: sanitizeSourceVariables(input.variables),
      // The stamp rate table charges duty on totalRent / loanAmount /
      // guaranteedAmount. Nothing ever populated these, so the adequacy check
      // returned early on every document. Derive them from the intake form.
      financials: resolveStampFinancials(input.variables || {}),
      state:
        input.variables?.governing_law_state ||
        input.variables?.operating_state ||
        draft?.metadata?.state ||
        null,
      interpreted_facts:
        input.semanticContext ||
        draft?.metadata?.interpreted_facts ||
        null,
      ai_touched: Boolean(draft?.metadata?.ai_touched),
      user_edited: Boolean(draft?.metadata?.user_edited),
      baseline_clause_map:
        resetBaseline || !existingBaseline
          ? buildBaselineClauseMap(draft?.clauses || [])
          : existingBaseline,
    },
  };
}

// A document is BLOCKED only by a blocking issue. Advisory findings -- a missing
// nice-to-have clause, a formatting nit, a stamp or registration notice -- are
// things the user should see ON the draft, not reasons to withhold it. Before
// this, `certified` meant "zero actionable issues of any severity", so a single
// MEDIUM advisory returned draft: null and the user got nothing at all.
function hasBlockingIssues(validation) {
  return (validation?.blockingIssues?.length ?? 0) > 0;
}

// Stricter test, used only to decide whether a draft is good enough to stop
// trying: a clean result short-circuits the repair round and, on the semantic
// path, is preferred over falling back to the deterministic draft.
function isGenerationReady(validation) {
  return (
    validation?.certified === true &&
    (validation?.summary?.total ?? validation?.issueCount ?? 0) === 0
  );
}

function buildGenerationFailureResult(validation) {
  const latestIssue =
    validation?.blockingIssues?.[0]?.message ||
    validation?.advisoryIssues?.[0]?.message;
  return {
    draft: null,
    validation,
    statusCode: 422,
    generation_guardrail_build: GENERATION_GUARDRAIL_BUILD,
    error: latestIssue
      ? `We couldn't produce a fully validated first draft yet. Latest issue: ${latestIssue}`
      : "We couldn't produce a fully validated first draft yet. Please try again.",
  };
}

function applyDeterministicRepairRound(draft, validation, input) {
  const issues = [
    ...(validation?.blockingIssues || []),
    ...(validation?.advisoryIssues || []),
  ];

  if (!issues.length) {
    return draft;
  }

  return applyFinalDraftGuardrails(applyDeterministicFixes(draft, issues), input);
}

function applyGenerationStages(draft, input) {
  if (!draft.metadata) draft.metadata = {};

  draft = resolveDependencies(draft, input);
  draft = injectJurisdictionRules(draft, input);
  draft = injectDoctrine(draft);
  draft = enforceScopeGuard(draft, input);
  draft = resolveSignatures(draft, input);
  draft = applyDocumentHardening(draft, input);
  draft = applyDocumentQualityControls(draft, input);
  draft = enhanceCommercially(draft);
  draft = lockCriticalClauses(draft);
  draft.document_type = input.document_type;

  try {
    const normalized = CategoryMapper.mapAndNormalize(draft);
    draft.clauses = normalized.clauses || draft.clauses;
  } catch {
    /* non-fatal */
  }

  draft = normalizeClauseText(draft);
  draft = applyDocumentQualityControls(draft, input);

  return draft;
}

function shouldUseSemanticGeneration(input = {}) {
  // Explicit opt-out always wins (lets callers force the deterministic path).
  if (input?.semantic_generation === false) return false;
  if (String(input?.generation_style || "").toLowerCase() === "deterministic") {
    return false;
  }

  // Explicit opt-in.
  if (
    input?.semantic_generation === true ||
    String(input?.generation_style || "").toLowerCase() === "semantic"
  ) {
    return true;
  }

  // Default: use semantic drafting whenever an AI provider is configured. The
  // deterministic pipeline below remains the automatic fallback if the provider
  // is unavailable, errors, or the AI draft fails final validation.
  return hasSemanticProviderConfigured();
}

function hasSemanticProviderConfigured() {
  return Boolean(process.env.GEMINI_API_KEY || process.env.GROQ_API_KEY);
}

function isSignatureClause(clause = {}) {
  return (
    clause?.category === "SIGNATURE_BLOCK" ||
    clause?.clause_id === "CORE_SIGNATURE_BLOCK_001"
  );
}

const PROTECTED_SEMANTIC_CATEGORIES = new Set([
  "IDENTITY",
  "GOVERNING_LAW",
  "DISPUTE_RESOLUTION",
  "SIGNATURE_BLOCK",
  "SIGNATURES",
  "LIABILITY_CAP",
]);

const PROTECTED_SEMANTIC_CLAUSE_IDS = new Set([
  "CORE_IDENTITY_001",
  "CORE_GOVERNING_LAW_001",
  "CORE_DISPUTE_RESOLUTION_001",
  "CORE_SIGNATURE_BLOCK_001",
  "CORE_LIABILITY_CAP_001",
]);

function isProtectedSemanticClause(clause = {}) {
  return Boolean(
    clause?.locked ||
      isSignatureClause(clause) ||
      PROTECTED_SEMANTIC_CATEGORIES.has(clause?.category) ||
      PROTECTED_SEMANTIC_CLAUSE_IDS.has(clause?.clause_id)
  );
}

function applyFinalDraftGuardrails(draft, input) {
  let next = resolveSignatures(draft, input);
  next = applyDocumentHardening(next, input);
  next = applyDocumentQualityControls(next, input);
  next = lockCriticalClauses(next);
  next = normalizeClauseText(next);
  next = applyDocumentQualityControls(next, input);
  return next;
}

// Resilient per-clause merge. The rule engine has ALREADY decided the clause set
// (the seed); the AI's job is to TAILOR the wording of each clause to the user's
// situation. So we never decide structure from the AI — we keep the seed's exact
// clause set, and for each clause use the AI's rewritten text when it returned a
// usable one, otherwise keep the deterministic (hardened) version. This turns the
// old all-or-nothing gate (one drift → 100% boilerplate) into "tailor what the AI
// rewrote, keep the rest." The merged draft is still validated downstream, and if
// it fails the deterministic base draft remains the safety net.
export function mergeAIDraftWithSeed(seedDraft, aiDraft, input, provider, options = {}) {
  if (!seedDraft?.clauses?.length || !aiDraft?.clauses?.length) {
    return null;
  }

  // Reject only on a genuine error: the AI drafted the WRONG document type.
  if (
    aiDraft.document_type &&
    String(aiDraft.document_type).toUpperCase() !==
      String(input.document_type).toUpperCase()
  ) {
    return null;
  }

  // Index the AI clauses that are actually usable (real id + non-empty text).
  const aiById = new Map(
    aiDraft.clauses
      .filter((c) => c?.clause_id && typeof c.text === "string" && c.text.trim())
      .map((c) => [c.clause_id, c])
  );
  if (aiById.size === 0) {
    return null; // nothing usable — fall back to the deterministic draft
  }

  // Stability across regens: a clause is UNCHANGED if a prior accepted version
  // exists and its deterministic seed text is identical to this regen's. For
  // those we reuse the prior AI-tailored wording verbatim, so a revision that
  // only changes the term never silently re-words clauses the user accepted.
  const priorById = options.priorClausesById || null;
  const isUnchanged = (seedClause) => {
    if (!priorById) return false;
    const prior = priorById.get(seedClause.clause_id);
    return Boolean(
      prior &&
        typeof prior.text === "string" &&
        prior.text.trim() &&
        prior._seed_text !== undefined &&
        prior._seed_text === seedClause._seed_text
    );
  };

  let tailored = 0;
  let reused = 0;
  const mergedClauses = seedDraft.clauses.map((seedClause) => {
    if (isProtectedSemanticClause(seedClause)) {
      return seedClause;
    }

    if (isUnchanged(seedClause)) {
      reused += 1;
      const prior = priorById.get(seedClause.clause_id);
      return { ...seedClause, text: prior.text }; // keep accepted wording + new seed meta
    }
    const aiClause = aiById.get(seedClause.clause_id);
    if (!aiClause) {
      return seedClause; // keep the deterministic, hardened clause as-is
    }
    tailored += 1;
    return {
      ...seedClause,
      ...aiClause,
      clause_id: seedClause.clause_id, // structure is the rule engine's, not the AI's
      category: aiClause.category || seedClause.category,
      title:
        typeof aiClause.title === "string" && aiClause.title.trim()
          ? aiClause.title
          : seedClause.title || null,
      statutory_reference:
        aiClause.statutory_reference ?? seedClause.statutory_reference ?? null,
      text: aiClause.text.trim(),
      _seed_text: seedClause._seed_text,
    };
  });

  const mergedDraft = normalizeClauseText({
    ...seedDraft,
    document_type: input.document_type,
    jurisdiction: aiDraft.jurisdiction || seedDraft.jurisdiction || "India",
    clauses: mergedClauses,
    metadata: {
      ...(seedDraft.metadata || {}),
      ai_touched: tailored > 0,
      ai_tailored_clause_count: tailored,
      ai_reused_clause_count: reused,
      ai_total_clause_count: seedDraft.clauses.length,
      ai_generation_provider: provider || null,
    },
  });

  return applyFinalDraftGuardrails(mergedDraft, input);
}

async function attemptSemanticDraft(seedDraft, input, options = {}) {
  if (!hasSemanticProviderConfigured()) {
    return null;
  }

  const priorClausesById = options.priorClausesById || null;

  // On a revision regen, only send the AI the clauses that actually changed
  // (new id, or its deterministic seed text differs from the accepted version).
  // Unchanged clauses keep their prior wording in the merge — so revisions are
  // fast and don't silently re-word what the user already accepted.
  let baseForAI = seedDraft;
  if (priorClausesById) {
    const changedClauses = seedDraft.clauses.filter((clause) => {
      if (isProtectedSemanticClause(clause)) return false;

      const prior = priorClausesById.get(clause.clause_id);
      return (
        !prior ||
        !prior.text ||
        prior._seed_text === undefined ||
        prior._seed_text !== clause._seed_text
      );
    });
    if (changedClauses.length === 0) {
      // Nothing to re-tailor — rebuild final wording from the prior draft.
      const unchangedDraft = normalizeClauseText({
        ...seedDraft,
        clauses: seedDraft.clauses.map((clause) => {
          if (isProtectedSemanticClause(clause)) {
            return clause;
          }

          const prior = priorClausesById.get(clause.clause_id);
          return prior?.text ? { ...clause, text: prior.text } : clause;
        }),
        metadata: { ...(seedDraft.metadata || {}), ai_touched: true, ai_tailored_clause_count: 0 },
      });

      return applyFinalDraftGuardrails(unchangedDraft, input);
    }
    baseForAI = { ...seedDraft, clauses: changedClauses };
  } else {
    const draftableClauses = seedDraft.clauses.filter(
      (clause) => !isProtectedSemanticClause(clause)
    );
    if (draftableClauses.length > 0) {
      baseForAI = { ...seedDraft, clauses: draftableClauses };
    }
  }

  const aiResult = await callAI({
    document_type: input.document_type,
    variables: input.variables || {},
    baseDraft: baseForAI,
    semanticContext: input.semanticContext,
  });

  if (!aiResult?.success || !aiResult?.draft) {
    return null;
  }

  return mergeAIDraftWithSeed(seedDraft, aiResult.draft, input, aiResult.provider, {
    priorClausesById,
  });
}

async function runGenerationStageValidation(draft, input, mode = "final") {
  return runDocumentValidation(
    {
      ...draft,
      jurisdiction: input.jurisdiction,
    },
    {
      // "final" = the strict six-layer gate (export). "generation" = the faster
      // interactive depth a revision regen requests. Export always forces final.
      mode,
      documentType: input.document_type,
      sourceVariables: input.variables,
      isUserEdit: false,
    }
  );
}

// Stamp each clause with its deterministic seed text so a later regen can tell
// which clauses are unchanged (and reuse their accepted wording).
function stampSeedText(draft) {
  if (!draft?.clauses) return draft;
  draft.clauses = draft.clauses.map((clause) => ({
    ...clause,
    _seed_text: typeof clause.text === "string" ? clause.text : "",
  }));
  return draft;
}

// Prior accepted clauses keyed by id (text + seed text) for stability matching.
function buildPriorClauseMap(priorDraft) {
  const map = new Map();
  for (const clause of priorDraft?.clauses || []) {
    if (clause?.clause_id) {
      map.set(clause.clause_id, { text: clause.text, _seed_text: clause._seed_text });
    }
  }
  return map;
}

export async function generateDocument(input, options = {}) {
  await loadIREModules();

  // Phase 5. Answers to the gap-check questions arrive here, are turned into
  // positions through the treatments table, and are merged into the intake
  // BEFORE anything is selected. The interview never says "add clause Y": it
  // establishes a fact, the knowledge base decides the treatment, and the
  // deterministic engine still owns the clause set exactly as before.
  //
  // The assumptions this produces travel with the result whether or not any
  // answers were given, because a document drafted on unstated defaults is the
  // case where the reader most needs to be told.
  let resolution = null;
  if (input.document_type) {
    try {
      resolution = resolvePositions({
        documentType: input.document_type,
        variables: input.variables || {},
        answers: input.answers || {},
      });
      if (Object.keys(resolution.positions).length) {
        input = {
          ...input,
          variables: {
            ...(input.variables || {}),
            // Carried under a reserved key rather than merged into the intake.
            // These are not form fields -- no form asks for
            // "processes_personal_data" -- so merging them as variables meant
            // sanitisation stripped them before they reached clause selection.
            __resolved_positions: serialisePositions(input.document_type, resolution.positions),
          },
        };
      }
    } catch (error) {
      // A failure to plan questions must never block a draft that would
      // otherwise generate. The document is produced without the layer and the
      // reason is recorded.
      resolution = { assumptions: [], error: String(error?.message || error) };
    }
  }
  options = { ...options, resolution };
  const mode = options.mode === "generation" ? "generation" : "final";
  const priorClausesById = options.priorDraft
    ? buildPriorClauseMap(options.priorDraft)
    : null;

  if (!input.document_type) {
    return buildBlockedGenerationResult([
      {
        rule_id: "MISSING_DOCUMENT_TYPE",
        severity: "CRITICAL",
        message: "document_type is required.",
      },
    ], { statusCode: 400 });
  }

  const inputCheck = validateInputByDocumentType(input);
  if (!inputCheck.valid) {
    return buildBlockedGenerationResult(
      inputCheck.errors.map((message, index) => ({
        rule_id: `INVALID_INPUT_${index + 1}`,
        severity: "CRITICAL",
        message,
      })),
      { statusCode: 400 }
    );
  }

  const generationInput = prepareGenerationInput(input);

  if (shouldUseSemanticGeneration(input)) {
    const semanticSeed = stampSeedText(
      applyGenerationStages(createBlueprintDraft(generationInput), generationInput)
    );
    const semanticDraft = await attemptSemanticDraft(semanticSeed, generationInput, {
      priorClausesById,
    });

    if (semanticDraft) {
      let draft = attachDraftContext(semanticDraft, generationInput, {
        resetBaseline: true,
      });
      let validation = await runGenerationStageValidation(draft, generationInput, mode);

      if (isGenerationReady(validation)) {
        return buildSuccess(draft, validation, options.resolution, { canonicalFacts: generationInput.canonicalFacts });
      }

      const repairedDraft = applyDeterministicRepairRound(
        draft,
        validation,
        generationInput
      );
      if (repairedDraft !== draft) {
        draft = attachDraftContext(repairedDraft, generationInput, {
          resetBaseline: true,
        });
        validation = await runGenerationStageValidation(draft, generationInput, mode);

        if (isGenerationReady(validation)) {
          return buildSuccess(draft, validation, options.resolution, { canonicalFacts: generationInput.canonicalFacts });
        }
      }

      // The tailored draft carries no blocking defect, only advisory findings.
      // Return it with those attached rather than discarding the tailoring and
      // falling back to boilerplate.
      if (!hasBlockingIssues(validation)) {
        return buildSuccess(draft, validation, options.resolution, { canonicalFacts: generationInput.canonicalFacts });
      }
    }
  }

  // Deterministic fallback remains the safety net when semantic drafting is
  // disabled, unavailable, or fails validation.
  const baseDraft = createDeterministicBaseDraft(generationInput);
  let draft = attachDraftContext(
    stampSeedText(applyGenerationStages(baseDraft, generationInput)),
    generationInput,
    {
      resetBaseline: true,
    }
  );
  let validation = await runGenerationStageValidation(draft, generationInput, mode);

  if (isGenerationReady(validation)) {
    return buildSuccess(draft, validation, options.resolution, { canonicalFacts: generationInput.canonicalFacts });
  }

  const repairedDraft = applyDeterministicRepairRound(
    draft,
    validation,
    generationInput
  );

  if (repairedDraft !== draft) {
    draft = attachDraftContext(repairedDraft, generationInput, {
      resetBaseline: true,
    });
    validation = await runGenerationStageValidation(draft, generationInput, mode);

    if (isGenerationReady(validation)) {
      return buildSuccess(draft, validation, options.resolution, { canonicalFacts: generationInput.canonicalFacts });
    }
  }

  // Only a blocking issue withholds the draft.
  if (!hasBlockingIssues(validation)) {
    return buildSuccess(draft, validation, options.resolution, { canonicalFacts: generationInput.canonicalFacts });
  }

  return buildGenerationFailureResult(validation);
}
