import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";
import {
  summariseProvenance,
  clauseReviewState,
  strictReviewRequired,
} from "../shared/clauseProvenance.js";

import { loadJSONFiles } from "./src/indian-rule-engine/loader.js";
import { IndianRuleRegistry } from "./src/indian-rule-engine/registry.js";
import { buildSchemaValidator } from "./src/indian-rule-engine/schemaValidator.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname  = path.dirname(__filename);

// Resolve KB path — works whether IRE is at /project/IRE/IRE or alongside /knowledge-base
const POSSIBLE_KB_PATHS = [
  path.resolve(__dirname, "../knowledge-base"),                     // LEGAL/knowledge-base/ (your structure)
  path.resolve(__dirname, "../../knowledge-base/knowledge-base"),   // double-nested fallback
  path.resolve(__dirname, "../knowledge-base/knowledge-base"),      // double-nested fallback
  path.resolve(__dirname, "knowledge-base"),                        // internal copy fallback
];

function findKBPath() {
  for (const p of POSSIBLE_KB_PATHS) {
    if (fs.existsSync(path.join(p, "clause_library"))) return p;
  }
  return null;
}

const KB_ROOT = findKBPath();

if (!KB_ROOT) {
  console.error("[IRE Bootstrap] ⚠️  Knowledge-base not found. Validation will be degraded.");
}

const CLAUSE_LIBRARY_PATH = KB_ROOT ? path.join(KB_ROOT, "clause_library") : null;
const CONSTRAINTS_PATH    = KB_ROOT ? path.join(KB_ROOT, "constraints")    : null;
const MAPPINGS_PATH       = KB_ROOT ? path.join(KB_ROOT, "mappings")       : null;
const BLUEPRINTS_PATH     = CLAUSE_LIBRARY_PATH ? path.join(CLAUSE_LIBRARY_PATH, "blueprints") : null;

// Schema validator (optional – skip if schema file missing)
let validateClause = () => {};
try {
  if (CLAUSE_LIBRARY_PATH) {
    const schemaPath = path.join(CLAUSE_LIBRARY_PATH, "base_clause.schema.json");
    if (fs.existsSync(schemaPath)) {
      const baseSchema = JSON.parse(fs.readFileSync(schemaPath, "utf8"));
      validateClause = buildSchemaValidator(baseSchema);
    }
  }
} catch { /* non-fatal */ }

export function bootstrapIRE() {

  const registry = new IndianRuleRegistry();

  if (!KB_ROOT) return registry;

  console.log("[IRE Bootstrap] Starting with KB:", KB_ROOT);

  // ── 1. Load clause library ──────────────────────────────────────────────
  const clauseFolders = CLAUSE_LIBRARY_PATH
    ? fs.readdirSync(CLAUSE_LIBRARY_PATH, { withFileTypes: true })
        .filter(d => d.isDirectory() && d.name !== "blueprints")
        .map(d => d.name)
    : [];
  let totalClauses = 0;
  const allLoadedClauses = [];
  const strictReview = strictReviewRequired();
  let refusedUnreviewed = 0;
  let deprecatedCount = 0;

  for (const folder of clauseFolders) {
    const folderPath = path.join(CLAUSE_LIBRARY_PATH, folder);
    if (!fs.existsSync(folderPath)) continue;

    const clauses = loadJSONFiles(folderPath);

    // Skip empty-text stub clauses (don't pollute registry with blank entries).
    // A clause marked `deprecated` is a superseded draft kept only so its id
    // stays resolvable in old saved documents. It is not loaded, so it cannot be
    // assembled into a new one -- and, importantly, it drops out of the review
    // provenance count, because asking an advocate to sign off text the product
    // can never emit is a waste of the only scarce resource here.
    const validClauses = clauses.filter(
      (c) => c.clause_id && c.text && c.text.trim().length > 0 && c.deprecated !== true
    );
    deprecatedCount += clauses.filter((c) => c.deprecated === true).length;

    validClauses.forEach(c => {
      try { validateClause(c); } catch { /* schema errors are non-fatal */ }
    });

    // Provenance gate. Under LEGALAID_REQUIRE_REVIEWED_CLAUSES=1 an unreviewed
    // clause is not loaded at all, so it cannot reach a generated document.
    // Off by default because the library is not yet reviewed — turning it on
    // today would load nothing. See shared/clauseProvenance.js.
    const admittedClauses = strictReview
      ? validClauses.filter((c) => {
          const admitted = clauseReviewState(c).reviewed;
          if (!admitted) refusedUnreviewed += 1;
          return admitted;
        })
      : validClauses;

    allLoadedClauses.push(...admittedClauses);
    registry.addClauses(admittedClauses);
    totalClauses += admittedClauses.length;
  }

  const provenance = summariseProvenance(allLoadedClauses);
  registry.clauseProvenance = provenance;

  console.log(
    `[IRE Bootstrap] Loaded ${totalClauses} clauses` +
      (deprecatedCount ? ` (${deprecatedCount} deprecated, not loaded)` : "")
  );
  if (strictReview) {
    console.log(
      `[IRE Bootstrap] Strict review mode: refused ${refusedUnreviewed} unreviewed clause(s)`
    );
  } else if (provenance.reviewed < provenance.total) {
    console.warn(
      `[IRE Bootstrap] ${provenance.total - provenance.reviewed} of ${provenance.total} clauses ` +
      `have no advocate sign-off (${provenance.awaiting_review} awaiting review, ` +
      `${provenance.unmarked} unmarked). Set LEGALAID_REQUIRE_REVIEWED_CLAUSES=1 to refuse them.`
    );
  }

  // ── 2. Load mappings (document_type → clause IDs) ───────────────────────
  if (MAPPINGS_PATH && fs.existsSync(MAPPINGS_PATH)) {
    const mappings = loadJSONFiles(MAPPINGS_PATH);
    let loaded = 0;

    for (const m of mappings) {
      if (!m.document_type || !m.clauses) continue;
      registry.addMapping(m.document_type, m.clauses);
      loaded++;
    }

    console.log(`[IRE Bootstrap] Loaded ${loaded} mappings`);
  }

  // ── 3. Load blueprints (blueprint clause sequences) ─────────────────────
  if (BLUEPRINTS_PATH && fs.existsSync(BLUEPRINTS_PATH)) {
    const blueprints = loadJSONFiles(BLUEPRINTS_PATH);
    let overridden = 0;
    let total = 0;

    for (const b of blueprints) {
      const clauseIds = b.required_clauses || b.clauses;
      if (!b.document_type || !Array.isArray(clauseIds)) continue;
      total++;
      if (registry.mappings.has(b.document_type)) {
        overridden++;
      }
      registry.addMapping(b.document_type, clauseIds);

      // Record variant substitution groups so a slot that REPLACES a required
      // clause with a context-matched alternative doesn't trip MISSING_REQUIRED_CLAUSE.
      const groups = [];
      for (const slot of b.variant_clauses || []) {
        if (!slot || !slot.replaces) continue;
        const candidates = slot.select_first_match || slot.variants || [];
        const alternatives = candidates
          .map((c) => c && c.clause)
          .filter(Boolean);
        if (slot.default) alternatives.push(slot.default);
        groups.push({ replaces: slot.replaces, alternatives });
      }
      registry.addVariantGroups(b.document_type, groups);
    }

    // Show total blueprints on disk, and how many doc types are registered overall
    console.log(
      `[IRE Bootstrap] Loaded ${total} blueprints (${overridden} overrides, ${registry.mappings.size} doc types registered total)`
    );
  }

  // ── 4. Load constraints (domain → rules) ────────────────────────────────
  if (CONSTRAINTS_PATH && fs.existsSync(CONSTRAINTS_PATH)) {
    const constraintFiles = loadJSONFiles(CONSTRAINTS_PATH);
    let loaded = 0;

    for (const f of constraintFiles) {
      if (!f.domain || !f.rules) continue;
      registry.addConstraints(f.domain, f.rules);
      loaded++;
    }

    console.log(`[IRE Bootstrap] Loaded ${loaded} constraint sets`);
  }

  console.log("[IRE Bootstrap] Ready ✓");

  return registry;
}
