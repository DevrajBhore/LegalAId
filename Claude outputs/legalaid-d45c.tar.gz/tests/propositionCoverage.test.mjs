/**
 * propositionCoverage.test.mjs — MUST THIS CLAUSE BE SPLIT?
 *
 * D4.5-B established that a clause can implement several legally distinct
 * propositions, and that the model handles ALTERNATIVE implementations (variant
 * slots) but not CONCURRENT ones with independent applicability. That left an
 * open question with real consequences: which composite clauses actually have to
 * be split, and which are composite but harmless?
 *
 * The criterion is not "the clause implements more than one proposition". A
 * clause may carry three propositions perfectly safely if they are applicable in
 * exactly the circumstances the clause is selected. The criterion is narrower and
 * checkable:
 *
 *     A proposition is LOST when there is a world in which it is applicable and
 *     no clause in the emitted document implements it.
 *
 * That is a runtime question, not a static one, so it is asked by generating the
 * worlds and reading the documents. A proposition can be carried by a clause that
 * was not selected and still be safe, because the variant default or another
 * clause implements it instead — which is exactly why static reasoning over
 * gates gets this wrong.
 *
 * WHAT THIS FOUND. `PRINCIPAL_EMPLOYER_EXPOSURE_ALLOCATED` — Code on Wages 2019
 * s.43 and EPF Act 1952 s.8A, the allocation that keeps the client from being
 * treated as principal employer of the provider's staff — is applicable to every
 * services engagement and is implemented only by `SERVICE_KEY_PERSONNEL_001`,
 * which is gated on `include_sla`. So an MSA with no agreed service levels
 * ALREADY ships without it. This is not a hypothetical consequence of a proposed
 * repair. It is live, in the current gate, today.
 *
 * The same test clears `NDA_CONFIDENTIALITY_TRADE_SECRET_001`, which is equally
 * composite: its broad proposition is picked up by the variant default when it is
 * not selected, so nothing is lost. Composite is not the defect. Divergent
 * applicability with no other implementer is.
 */
import assert from "node:assert";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { generateDocument } from "../backend/services/documentService.js";
import { getVariables } from "../backend/config/variableConfig.js";
import { variablesFor, FIXTURE_PROFILE } from "../sweep.mjs";
import { optionMeaning } from "../scripts/lib/semanticMutation.mjs";
import { POSITION } from "../backend/services/generationControls.js";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.join(HERE, "..");
const readJson = (p) => JSON.parse(fs.readFileSync(p, "utf8"));

const propositions = new Map(
  readJson(path.join(ROOT, "knowledge-base/propositions/propositions.json"))
    .propositions.map((p) => [p.proposition_id, p]));

const implementers = new Map();
(function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, entry.name);
    if (entry.isDirectory()) { if (entry.name !== "blueprints") walk(p); continue; }
    if (!entry.name.endsWith(".json") || entry.name.includes("schema")) continue;
    let doc; try { doc = readJson(p); } catch { continue; }
    for (const c of Array.isArray(doc) ? doc : [doc]) {
      for (const id of c?.implements || []) {
        if (!implementers.has(id)) implementers.set(id, new Set());
        implementers.get(id).add(c.clause_id);
      }
    }
  }
})(path.join(ROOT, "knowledge-base/clause_library"));

/** Document types whose annotated clauses we can reason about. */
const SUBJECTS = ["MASTER_SERVICE_AGREEMENT", "NDA", "LOAN_AGREEMENT"];

/**
 * Worlds to examine: the baseline, plus each material binary answered FALSE.
 * Answering things false is where propositions go missing — a world with
 * everything switched on hides exactly the defect being looked for.
 */
async function worlds(documentType) {
  const schema = getVariables(documentType) || {};
  const base = variablesFor(documentType, { profile: FIXTURE_PROFILE.WELL_FILLED });
  const cases = [{ label: "baseline", variables: base }];
  for (const [field, def] of Object.entries(schema)) {
    if (def.type !== "select" || !Array.isArray(def.options)) continue;
    const no = optionMeaning(def, POSITION.FALSE);
    if (no === null) continue;
    cases.push({ label: `${field}=no`, variables: { ...base, [field]: no } });
  }

  const out = [];
  for (const c of cases) {
    let result;
    try { result = await generateDocument({ document_type: documentType, variables: c.variables }); }
    catch { continue; }
    const clauses = result.draft?.clauses || [];
    if (!clauses.length) continue;  // blocked or contradictory: not a measurement
    out.push({ ...c, ids: clauses.map((x) => x.clause_id),
      controls: result.draft?.metadata?.resolved_generation_controls || {} });
  }
  return out;
}

/** Is the proposition applicable in this world? */
function applicable(proposition, world) {
  const a = proposition.applicability || {};
  if (a.always === true) return true;
  if (!a.position) return false;
  const actual = world.controls[a.position] ?? world.variables[a.position];
  const text = String(actual ?? "").trim().toLowerCase();
  const truthy = ["yes", "true", "y"].includes(text) || actual === true;
  return a.value === false ? !truthy : truthy;
}

let checks = 0;
const lost = [];

for (const documentType of SUBJECTS) {
  const all = await worlds(documentType);
  if (!all.length) continue;

  /* Only propositions some clause in this family can implement are in scope. */
  const inScope = [...propositions.values()].filter((p) =>
    all.some((w) => w.ids.some((id) => implementers.get(p.proposition_id)?.has(id))));

  for (const proposition of inScope) {
    for (const world of all) {
      if (!applicable(proposition, world)) continue;
      const covered = world.ids.some((id) => implementers.get(proposition.proposition_id)?.has(id));
      if (covered) continue;
      lost.push({
        documentType, world: world.label,
        proposition_id: proposition.proposition_id,
        authority: (proposition.authority || []).map((x) => `${x.act}${x.section ? ` s.${x.section}` : ""}`),
        implementers: [...(implementers.get(proposition.proposition_id) || [])],
      });
    }
    checks += 1;
  }
}

/* Collapse to one row per (type, proposition) — the worlds are evidence, not findings. */
const byProposition = new Map();
for (const l of lost) {
  const key = `${l.documentType}/${l.proposition_id}`;
  if (!byProposition.has(key)) byProposition.set(key, { ...l, worlds: [] });
  byProposition.get(key).worlds.push(l.world);
}

const KNOWN = new Map(Object.entries({
  "MASTER_SERVICE_AGREEMENT/PRINCIPAL_EMPLOYER_EXPOSURE_ALLOCATED":
    "LIVE DEFECT, not hypothetical. Applicable to every services engagement; implemented only by " +
    "SERVICE_KEY_PERSONNEL_001, which is gated on include_sla. An MSA with no agreed service " +
    "levels ships today with nothing allocating principal-employer exposure under Code on Wages " +
    "s.43 / EPF s.8A. The repair is to split the clause so this limb is unconditional; that is " +
    "new legal text and needs advocate review. Recorded in " +
    "knowledge-base/governance/statutory-custody.json.",
  "MASTER_SERVICE_AGREEMENT/PERSONAL_PERFORMANCE_INTENDED":
    "LIVE DEFECT, and the D4.3 GATE_FACT_MISMATCH stated as an actual legal loss rather than as a " +
    "wiring observation. The clause is gated on include_sla while this proposition is applicable on " +
    "key_person_dependency, so a client who answers YES to depending on particular individuals and " +
    "NO to agreed service levels receives no key-person protection at all, silently. Unlike the " +
    "principal-employer limb this one does NOT need the clause split — it needs the gate moved onto " +
    "the fact its own proposition names. But the two repairs must land together: moving the gate " +
    "while the clause is still composite would take the principal-employer allocation with it, " +
    "which is the regression statutory-custody.json records as BLOCKED.",
}));

const unexpected = [...byProposition.keys()].filter((k) => !KNOWN.has(k));
assert.deepStrictEqual(unexpected, [],
  "A legal proposition is applicable in some world and implemented by no clause in the document:\n" +
  unexpected.map((k) => {
    const r = byProposition.get(k);
    return `  ${k}\n    authority: ${r.authority.join("; ")}\n` +
           `    implemented only by: ${r.implementers.join(", ")}\n` +
           `    lost in ${r.worlds.length} world(s), e.g. ${r.worlds.slice(0, 3).join(", ")}`;
  }).join("\n") +
  "\nEither another clause must implement it, or the carrying clause must be split.");

const repaired = [...KNOWN.keys()].filter((k) => !byProposition.has(k));
assert.deepStrictEqual(repaired, [],
  `Recorded proposition-loss no longer occurs. If repaired, delete from KNOWN:\n  ${repaired.join("\n  ")}`);
checks += 2;

for (const [key, record] of byProposition) {
  const worlds = record.worlds.length;
  console.log(`KNOWN  ${key} — lost in ${worlds} world(s)`);
  console.log(`       ${KNOWN.get(key).split(". ")[0]}.`);
}
console.log(`PASS  ${checks - 2} proposition/family pairs examined; ` +
  `${byProposition.size} losses, all recorded`);
console.log(`\nALL GREEN (${checks} checks)`);
