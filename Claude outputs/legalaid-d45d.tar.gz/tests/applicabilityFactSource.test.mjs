/**
 * applicabilityFactSource.test.mjs
 *
 * INVERTED. This file used to RECORD the defect; it now guards the repair.
 *
 * What it recorded: clause selection read deriveGenerationControls, assessment
 * read resolution.positions, and a requirement conditioned on a derived fact
 * reported APPLICABILITY_UNKNOWN while the same document shipped the clause that
 * fact had gated. Nine of nine conditional requirements, across three families.
 * The document acted and the report said nobody knew.
 *
 * What it guards now: there is ONE resolution, computed upstream of generation
 * in prepareGenerationInput and carried to assessment. Both halves read the same
 * object.
 *
 * WHY THIS FILE IS STILL SEPARATE FROM factSourceParity.test.mjs. That file
 * proves the two halves AGREE. This one proves the nine requirements the defect
 * was measured on are actually DETERMINATE — which is a different claim, and the
 * weaker one. Two halves can agree perfectly that a fact is unknown. The
 * original count is preserved so the repair is measured against the thing that
 * was broken, not against a fresh set of examples chosen after the fact.
 *
 * THE SUCCESS CRITERION IS NOT "NINE OF NINE GREEN". It is that every
 * requirement evaluates against the facts generation used. A requirement moving
 * to NOT_APPLICABLE is not a win here: on the employment fixture it means the
 * POSH Internal Committee and maternity requirements are now reported as not
 * applying, on a derivation whose legal correctness is still an open question
 * carried on those requirements. Determinate is not the same as right.
 */
import assert from "node:assert";
import { loadDocumentRequirements, COVERAGE } from "../backend/services/documentRequirements.js";
import { buildVariables } from "../scripts/freezeClauseBaseline.mjs";
import { generateDocument } from "../backend/services/documentService.js";

let checks = 0;

// The families the defect was measured on, and every requirement in them whose
// applicability rests on a fact.
const requirements = loadDocumentRequirements({ refresh: true });
const FAMILIES = ["LOAN_AGREEMENT", "EMPLOYMENT_CONTRACT", "MASTER_SERVICE_AGREEMENT"];

const rows = [];
for (const family of FAMILIES) {
  const positioned = (requirements.get(family) || []).filter((r) => r.applicability?.position);
  if (!positioned.length) continue;
  const result = await generateDocument({
    document_type: family, variables: buildVariables(family, "full"),
  });
  assert.ok(
    (result.draft?.clauses || []).length > 0,
    `${family}: the fixture no longer generates, so nothing below was measured`
  );
  const facts = new Map((result.canonical_facts || []).map((o) => [o.fact, o]));
  for (const requirement of positioned) {
    const assessed = result.requirements.results.find((r) => r.id === requirement.id);
    rows.push({
      family, id: requirement.id, flag: requirement.applicability.position,
      coverage: assessed?.coverage, fact: facts.get(requirement.applicability.position),
    });
  }
}

assert.ok(
  rows.length >= 9,
  `only ${rows.length} position-conditioned requirements found; the defect was measured on 9. ` +
  `If requirements were removed or re-gated, say so here rather than lowering the number.`
);
checks += 1;

// 1. Every one of them is determinate — the defect is gone.
const undetermined = rows.filter((r) => r.coverage === COVERAGE.APPLICABILITY_UNKNOWN);
assert.deepEqual(
  undetermined.map((r) => `${r.family}/${r.id} (${r.flag})`), [],
  "a position-conditioned requirement is undetermined on a fixture that answers its fact"
);
checks += 1;

// 2. And determinate BECAUSE the fact reached it, not by defaulting. Every one
//    names the fact it rested on, with that fact established and its evidence
//    stated. A requirement that resolved while its fact was unknown would be
//    the original defect running in the other direction.
for (const row of rows) {
  assert.ok(
    row.fact, `${row.family}/${row.id}: rests on "${row.flag}", which is not in canonical_facts`
  );
  assert.notEqual(
    row.fact.provenance, "unknown",
    `${row.family}/${row.id}: resolved to ${row.coverage} while "${row.flag}" is unestablished. ` +
    `The requirement reached a finding without the fact it depends on.`
  );
  assert.ok(
    row.fact.evidence.length > 0,
    `${row.family}/${row.id}: "${row.flag}" is established but names no evidence`
  );
}
checks += rows.length;

// 3. The sharpest case, stated as the document and the report agreeing: the
//    loan asserts security in its clauses and the report says security applies.
const loan = await generateDocument({
  document_type: "LOAN_AGREEMENT", variables: buildVariables("LOAN_AGREEMENT", "full"),
});
const isSecured = (loan.canonical_facts || []).find((o) => o.fact === "is_secured");
assert.strictEqual(isSecured.value, true, "the loan fixture is no longer secured — pick one that is");
assert.ok(
  (loan.draft?.clauses || []).some((c) => c.clause_id === "LOAN_SECURITY_001"),
  "the shipped secured loan carries no security clause"
);
assert.strictEqual(
  loan.requirements.results.find((r) => r.id === "SECURITY_POSITION_SETTLED").coverage,
  COVERAGE.RESOLVED,
  "the document asserts security and the report does not agree that security applies"
);
checks += 3;

const byState = rows.reduce((acc, r) => ({ ...acc, [r.coverage]: (acc[r.coverage] || 0) + 1 }), {});
console.log(
  `PASS  ${rows.length} position-conditioned requirements are determinate, each against an ` +
  `established fact\n      ${JSON.stringify(byState)}`
);
console.log(
  `NOTE  determinate is not the same as correct. ${byState[COVERAGE.NOT_APPLICABLE] || 0} of them ` +
  `report NOT_APPLICABLE, which is\n      a finding of fact — the derivations behind those carry ` +
  `open legal questions.`
);
console.log(`\nALL GREEN (${checks} checks)`);
