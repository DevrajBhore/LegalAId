import assert from "node:assert";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

import {
  clauseReviewState,
  summariseProvenance,
  REVIEW_STATE,
} from "../shared/clauseProvenance.js";

// ── 1. What counts as a signature ────────────────────────────────────────────
assert.strictEqual(
  clauseReviewState({ clause_id: "X", reviewed_by: "PENDING" }).reviewed,
  false,
  '"PENDING" is a placeholder, not a reviewer'
);
assert.strictEqual(
  clauseReviewState({ clause_id: "X", reviewed_by: "Adv. R. Menon", review_status: "draft-needs-legal-review" }).reviewed,
  false,
  "a named reviewer does not override a status that still says it needs review"
);
assert.strictEqual(
  clauseReviewState({ clause_id: "X", reviewed_by: "Adv. R. Menon", reviewed_on: "2026-08-20" }).reviewed,
  true
);
assert.strictEqual(clauseReviewState({ clause_id: "X" }).state, REVIEW_STATE.UNMARKED);
console.log("PASS  review-state semantics (placeholders rejected)");

// ── 2. The backlog can only shrink ──────────────────────────────────────────
// Pinned so that adding a NEW unreviewed clause fails the build, while every
// clause that gets signed off moves the numbers in the right direction.
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const CLAUSE_LIB = path.join(ROOT, "knowledge-base", "clause_library");

const clauses = [];
for (const folder of fs.readdirSync(CLAUSE_LIB, { withFileTypes: true })) {
  if (!folder.isDirectory() || folder.name === "blueprints") continue;
  for (const file of fs.readdirSync(path.join(CLAUSE_LIB, folder.name))) {
    if (!file.endsWith(".json")) continue;
    const clause = JSON.parse(
      fs.readFileSync(path.join(CLAUSE_LIB, folder.name, file), "utf8")
    );
    // A deprecated clause is not loaded by the engine and can never reach a
    // document, so it must not sit in the review queue either -- counting it
    // would ask an advocate to sign off text the product cannot emit. Mirrors
    // the filter in IRE/bootstrap.js.
    if (clause?.clause_id && clause.deprecated !== true) clauses.push(clause);
  }
}

const summary = summariseProvenance(clauses);
// Raised from 190 to 191 for CORE_INSURANCE_001, added because the library
// carried no insurance covenant at any deal size. It is marked
// review_status: draft-needs-legal-review / reviewed_by: PENDING like the rest.
// This ceiling only ever moves up for a deliberately added clause; it should
// come down as the supervising advocate signs clauses off.
// Raised to 250: sixteen clauses were added for four startup and fundraising
// document types -- a Founders' Agreement (4), a Term Sheet (4), an ESOP Grant
// Letter (5) and a Share Subscription Agreement (3). This family reused more
// than expected: anti-dilution, drag, tag, pre-emption, board control and
// deadlock clauses were already in the library. Previously 234 after sixteen
// clauses were added for three standalone instruments --
// a Promissory Note (5), an IP Assignment Agreement (6), and a Power of
// Attorney (5). Two clauses already in the library, PROMISSORY_NOTE_PAYMENT_001
// and IP_PATENT_RIGHTS_001, were written for those types and had been
// unreachable while the types did not exist; they are now placed, which takes
// the library to zero orphaned clauses. Previously 218 after eighteen
// clauses were added for three data and e-commerce
// document types -- a DPDP-compliant Data Processing Agreement (8), a Refund
// and Cancellation Policy (4), a Shipping and Delivery Policy (4), and two
// clauses shared between the two policies. Previously 200 after sixteen
// clauses were added for four new employment document
// types -- appointment letter (3), internship agreement (3), separation and
// full-and-final settlement (4), and a standalone PoSH policy (6). Every one
// carries an authoring_note naming the specific judgement the advocate must
// make, so the queue grew by sixteen decisions, not sixteen blank pages.
// Previously 184, after eight superseded clauses were deprecated and left the
// queue -- five duplicated general provisions, and three older rental clauses
// replaced by the templated RENTAL_* set. Previously raised to 192 because
// CORE_REPRESENTATIONS_001 was added, since the
// Events of Default clause in the guarantee and loan agreements defaulted on
// "breach of any representation" in documents that contained none. It carries
// review_status draft-needs-legal-review like the rest of the library.
// Previously 250. Raised to 289 for the notices and dispute-instruments family:
// thirty-nine clauses across a legal notice, a Section 138 cheque bounce notice,
// a reply, a Section 21 arbitration notice, a settlement agreement, an affidavit
// and an indemnity bond. These carry more review weight per clause than the
// average, not less - a Section 138 notice that is wrong is not a bad document,
// it is a destroyed prosecution - so the queue should be worked in that order.
// Every one carries an authoring_note naming the judgement the advocate must
// make, and two carry statute_currency flags as well.
// Raised to 290 for TOS_FEES_AND_BILLING_001. A terms-of-service document for a
// paid service previously carried no fee, billing or cancellation terms at all,
// so the clause closes a real gap rather than adding depth to a covered area.
// It anchors on the Consumer Protection (E-Commerce) Rules 2020 r.4(3) price
// display duty and CGST s.31 invoicing, and its authoring_note asks the
// reviewing advocate one specific question: whether the document should also
// describe the RBI e-mandate mechanics for a recurring card subscription, which
// sit with the payment aggregator rather than the merchant's terms.
// Raised to 291 for CORE_GOVERNANCE_PROTECTIONS_001. Four intake fields --
// audit rights, information rights, escalation mechanism and additional
// protections -- were collected on seven document types and could reach the
// page on none of them unless the document happened to carry a reporting or
// JV-governance clause. The clause gives them a home. Its authoring_note asks
// the reviewer two questions: whether three years is the right default
// retention, and whether an escalation route should be a precondition to formal
// remedies or only a commercial preference.
// Raised to 294 for the intent layer: CORE_TRANSITION_ASSISTANCE_001,
// SUPPLY_PRICE_REVISION_001 and SERVICE_EXCLUSIVITY_001. These are the three
// clauses the objectives checklist selects that the library did not already
// hold. Each carries an authoring_note naming what the reviewer must settle:
// the thirty-day transition default and whether the no-withholding sentence
// survives an unpaid invoice; whether WPI is the right index and whether falls
// as well as rises should pass through; and whether a during-term exclusivity
// is the furthest a consultancy agreement can go under section 27.
// Raised to 301 for the seven MSA clauses. A Master Service Agreement checklist
// was reviewed against what the blueprint actually emits, and these were the
// headings the library could not serve at all: MSA_SUBCONTRACTING_001,
// SERVICE_IMPLIED_SERVICES_001, MSA_GOVERNANCE_BODY_001,
// SERVICE_CUSTOMER_DEPENDENCIES_001, SERVICE_KEY_PERSONNEL_001,
// CORE_RESIDUAL_KNOWLEDGE_001 and CORE_INDEMNITY_PROCEDURE_001.
//
// Two of them carry more reviewer risk than the rest and should be read first.
// CORE_RESIDUAL_KNOWLEDGE_001 is the provision most commonly over-drafted in a
// services agreement: too wide and it hollows out the confidentiality
// obligation beside it, too narrow and section 27 of the Contract Act makes the
// confidentiality obligation itself a restraint. CORE_INDEMNITY_PROCEDURE_001
// exists because CORE_INDEMNITY_001 grants an indemnity and says nothing about
// how a claim is run, which is where an indemnity usually fails -- section 125
// makes recovery conditional on the indemnity-holder's prudence and on not
// contravening the indemnifier's orders, so the machinery is not decoration.
// Raised to 307 for the six clauses migrated out of
// backend/commercial/protectionLibrary.js. Their TEXT is unchanged -- the
// migration moved them into the governed library so they could carry a review
// status at all. Three of them were already reaching shipped documents in seven
// document types with no way for an advocate to sign them off, so this is a
// backlog that was always there and is only now visible.
// Raised to 308 in D4.5-C for SERVICE_PERSONNEL_STATUS_001. The increment is a
// SPLIT, not new legal content: the clause carries two sentences moved verbatim
// out of SERVICE_KEY_PERSONNEL_001 because they implement a proposition with
// different applicability (Code on Wages s.43 / EPF s.8A, applicable to every
// services engagement) from the one the clause was gated on. No wording was
// authored. The debt still rises by one, and that is correct: an advocate must
// now sign off two clauses where one stood, and the boundary between them is
// itself a legal judgement that deserves review.
const MAX_UNREVIEWED = 308;

console.log(
  `      library: ${summary.total} clauses, ${summary.reviewed} reviewed, ` +
  `${summary.awaiting_review} awaiting review, ${summary.unmarked} unmarked`
);
assert.ok(
  summary.total - summary.reviewed <= MAX_UNREVIEWED,
  `unreviewed clause count rose to ${summary.total - summary.reviewed}, above the pinned ceiling of ${MAX_UNREVIEWED}. ` +
  `Either get the new clause reviewed, or lower the ceiling deliberately.`
);
console.log(`PASS  unreviewed backlog within the pinned ceiling of ${MAX_UNREVIEWED}`);

// ── Citation identity is not substring matching ─────────────────────────────
// A review asked one line about "the Section 43A IT Act reference". Scanning for
// the string "43A" returned twelve clauses; eleven cite it in legal_basis.section
// and the twelfth mentions section 143A of the Negotiable Instruments Act in
// prose. The same token-boundary class as the money regex that once read
// `parent_name` as a rent field and filled a deponent's parent with Rs. 5,00,000.
//
// A legal proposition propagating through many clauses is exactly when a
// miscount matters, so the population is defined by the structured field.
function clausesCiting(act, section) {
  return clauses.filter((clause) =>
    (clause.legal_basis || []).some(
      (basis) =>
        String(basis.act || "").includes(act) &&
        String(basis.section || "").trim() === section
    )
  );
}
const citing43A = clausesCiting("Information Technology Act, 2000", "43A");
const mentioning43A = clauses.filter((clause) => JSON.stringify(clause).includes("43A"));
assert.ok(mentioning43A.length > citing43A.length,
  "the corpus no longer contains a clause that mentions 43A without citing it, so this " +
  "regression can no longer be demonstrated — confirm that is intended before deleting it");
assert.ok(!citing43A.some((c) => c.clause_id === "S138_CONSEQUENCE_001"),
  "S138_CONSEQUENCE_001 counted as citing IT Act s.43A. It mentions section 143A of the " +
  "Negotiable Instruments Act in prose. Citation identity must be read from " +
  "legal_basis.section, never from a substring of the record.");
console.log(
  `PASS  citation identity: ${citing43A.length} clauses cite IT Act s.43A, ` +
  `${mentioning43A.length} records merely contain the string`
);

// ── 3. Every clause I authored declares its status ──────────────────────────
const authored = clauses.filter((c) => c.review_status);
assert.ok(
  authored.length >= 2,
  "clauses authored by tooling must declare review_status"
);
for (const clause of authored) {
  assert.ok(
    [REVIEW_STATE.DRAFT, REVIEW_STATE.APPROVED, "approved-pending-activation"].includes(
      String(clause.review_status)
    ),
    `unexpected review_status on ${clause.clause_id}: ${clause.review_status}`
  );
}
console.log(`PASS  ${authored.length} clause(s) carry an explicit review_status`);

// ── 4. Every citation is well-formed ────────────────────────────────────────
let citations = 0;
for (const clause of clauses) {
  assert.ok(
    Array.isArray(clause.legal_basis) && clause.legal_basis.length > 0,
    `${clause.clause_id} has no legal_basis`
  );
  for (const entry of clause.legal_basis) {
    citations += 1;
    assert.ok(entry?.act, `${clause.clause_id} has a legal_basis entry with no act`);
    assert.ok(
      entry.section || entry.article,
      `${clause.clause_id} cites "${entry.act}" with neither section nor article`
    );
  }
}
console.log(`PASS  ${citations} statutory citations well-formed across ${clauses.length} clauses`);

console.log("\nALL GREEN");
