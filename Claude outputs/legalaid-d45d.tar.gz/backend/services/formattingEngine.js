const RUPEE = "\u20b9";

const ONES = [
  "",
  "One",
  "Two",
  "Three",
  "Four",
  "Five",
  "Six",
  "Seven",
  "Eight",
  "Nine",
  "Ten",
  "Eleven",
  "Twelve",
  "Thirteen",
  "Fourteen",
  "Fifteen",
  "Sixteen",
  "Seventeen",
  "Eighteen",
  "Nineteen",
];

const TENS = [
  "",
  "",
  "Twenty",
  "Thirty",
  "Forty",
  "Fifty",
  "Sixty",
  "Seventy",
  "Eighty",
  "Ninety",
];

export function parseNumberish(value) {
  if (value === undefined || value === null || value === "") return null;
  // Strip BOTH commas and internal whitespace before parsing — an already-
  // formatted Indian amount like "5,00,000" (or one captured with stray spaces,
  // "5 00 000") must parse to 500000, not 5 (parseFloat-style truncation at the
  // first separator was corrupting re-normalized amounts, e.g. ₹5,00,000 → ₹5).
  const match = String(value).replace(/[\s,]/g, "").match(/-?\d+(?:\.\d+)?/);
  if (!match) return null;
  const parsed = Number(match[0]);
  return Number.isFinite(parsed) ? parsed : null;
}

function formatBelowHundred(value) {
  if (value < 20) return ONES[value];
  const ten = Math.floor(value / 10);
  const one = value % 10;
  return [TENS[ten], ONES[one]].filter(Boolean).join(" ");
}

function formatBelowThousand(value) {
  const hundred = Math.floor(value / 100);
  const rest = value % 100;
  return [
    hundred ? `${ONES[hundred]} Hundred` : "",
    rest ? formatBelowHundred(rest) : "",
  ]
    .filter(Boolean)
    .join(" ");
}

export function amountToIndianWords(value) {
  const numeric = Math.round(Math.abs(Number(value)));
  if (!Number.isFinite(numeric)) return "";
  if (numeric === 0) return "Zero";

  const crore = Math.floor(numeric / 10000000);
  const lakh = Math.floor((numeric % 10000000) / 100000);
  const thousand = Math.floor((numeric % 100000) / 1000);
  const rest = numeric % 1000;

  return [
    crore ? `${formatBelowThousand(crore)} Crore` : "",
    lakh ? `${formatBelowThousand(lakh)} Lakh` : "",
    thousand ? `${formatBelowThousand(thousand)} Thousand` : "",
    rest ? formatBelowThousand(rest) : "",
  ]
    .filter(Boolean)
    .join(" ");
}

export function formatIndianAmount(value, { includeWords = false } = {}) {
  const numeric = parseNumberish(value);
  if (numeric === null) return "the agreed amount";
  const rounded = Math.round(numeric);
  const formatted = `${RUPEE}${rounded.toLocaleString("en-IN")}`;
  if (!includeWords) return formatted;
  return `${formatted} (Rupees ${amountToIndianWords(rounded)} Only)`;
}

export function formatFormalDate(value) {
  const raw = String(value || "").trim();
  if (!raw) return "the agreed date";
  const parsed = new Date(raw);
  if (Number.isNaN(parsed.getTime())) return raw;
  // House style is "1 September 2026" throughout. The zero-padded form read as a
  // second date format sitting beside the ordinal one used in the testatum
  // ("this 1st day of September, 2026"), and one document should not present
  // dates two ways.
  const month = parsed.toLocaleString("en-GB", { month: "long" });
  return `${parsed.getDate()} ${month} ${parsed.getFullYear()}`;
}

export function normalizeCurrencyText(text = "", { includeWords = false } = {}) {
  return String(text || "").replace(
    /(?:\u20b9|\u00b9|â‚¹)\s*(-?\d(?:[\d\s]|,(?=\d))*(?:\.\d+)?)/g,
    (_match, amount, offset, source) => {
      const numeric = parseNumberish(amount);
      if (numeric === null) return _match;
      // The amount class consumes any trailing whitespace before the next token;
      // preserve it so we don't fuse the amount with the following word
      // (e.g. "₹5,00,000(Rupees…" or "…Only)prior").
      //
      // The class used to be [\d,\s]*, which also swallowed a comma that merely
      // FOLLOWED the amount: "₹5,00,000, which is the total" captured
      // "5,00,000, " and the rewritten sentence came back without its comma. In
      // Indian digit grouping a comma is only part of a number when digits come
      // after it, so the comma now has to be followed by one to be consumed.
      const trailingWs = (amount.match(/\s+$/) || [""])[0];
      const tail = source.slice(offset + _match.length, offset + _match.length + 24);
      const formatted = formatIndianAmount(numeric, {
        includeWords: includeWords && !/^\s*\(Rupees\b/i.test(tail),
      });
      return formatted + trailingWs;
    }
  );
}
