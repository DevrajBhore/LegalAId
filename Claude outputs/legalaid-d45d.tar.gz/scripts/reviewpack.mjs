/**
 * Measures which clauses each document type actually renders, and writes
 * reviewpack.json for scripts/buildReviewPack.py.
 *
 * Run from the repository root:   node scripts/reviewpack.mjs
 *
 * Self-contained by design. This script used to read its sample-value generator
 * out of a sweep.mjs sitting in the repository root, which meant it could not be
 * run from a clean checkout at all. The sampler is inlined below instead.
 */
import { DOCUMENT_TYPE_REGISTRY } from "../shared/documentRegistry.js";
import { VARIABLE_CONFIG } from "../backend/config/variableConfig.js";
import { sampleFor, FIXTURE_PROFILE } from "../sweep.mjs";
import { generateDocument } from "../backend/services/documentService.js";
import fs from "fs";
import path from "path";

const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname), "..");

const SAMPLES = { name:"Alpha Industries Private Limited", address:"1 First Road, Mumbai, Maharashtra 400001",
  email:"contact@alpha.example", url:"https://alpha.example", city:"Pune", state:"Maharashtra",
  date:"2026-09-01", number:"500000", pan:"AAACA1234A", gstin:"27AAACA1234A1Z5",
  cin:"U74999MH2015PTC123456", llpin:"AAB-1234" };

/* ── Sample-value generator ──────────────────────────────────────────────── */
const ENTITY_NAMES = [
  "Alpha Industries Private Limited",
  "Beta Consulting LLP",
  "Gamma Ventures Private Limited",
];
const PERSON_NAMES = ["Ramesh Kulkarni", "Sunita Deshmukh", "Arjun Nair"];
// Which of the two pools each party slot draws from.
const ENTITY_OR_PERSON = [ENTITY_NAMES[0], ENTITY_NAMES[1], ENTITY_NAMES[2]];
const ADDRESSES = [
  "1 First Road, Mumbai, Maharashtra 400001",
  "2 Second Road, Pune, Maharashtra 411001",
  "3 Third Road, Nashik, Maharashtra 422001",
];

// Distinguish the first, second and third counterparty so the fixture doesn't
// name both sides identically (which is itself a validation failure).
function partyIndex(key) {
  if (/(_|\b)(2|second|b)\b|_2_|employee|licensee|tenant|borrower|buyer|purchaser|contractor|consultant|distributor|recipient|service_provider/i.test(key)) return 1;
  if (/(_|\b)(3|third)\b|_3_|guarantor|witness/i.test(key)) return 2;
  return 0;
}

// THE SAMPLER LIVES IN ONE PLACE.
//
// This file carried its OWN copy of sampleFor — 18 of its 25 lines identical to
// sweep.mjs's — with its own SAMPLES table. Two fixture generators, and only one
// of them learned that `options[0]` is "No" for every optional protection, so
// the fixture-profile repair landed in sweep.mjs and left this one declining
// every optional protection while claiming to build a review pack.
//
// Imported rather than re-copied, and the PROFILE is stated: an advocate reading
// a review pack should see the clauses a document carries when its optional
// protections are accepted, not the subset left after declining all of them.

const usage = new Map();
for (const docType of Object.keys(DOCUMENT_TYPE_REGISTRY)) {
  const all = { ...(VARIABLE_CONFIG.COMMON||{}), ...(VARIABLE_CONFIG[docType]||{}) };
  const vars = {};
  for (const [k, d] of Object.entries(all)) {
    if (Array.isArray(d.excludeDocuments) && d.excludeDocuments.includes(docType)) continue;
    if (!d.required) continue;
    vars[k] = sampleFor(k, d, { profile: FIXTURE_PROFILE.WELL_FILLED });
  }
  let r;
  for (let i = 0; i < 15; i += 1) {
    r = await generateDocument({ document_type: docType, variables: vars });
    if (r?.draft) break;
    const m = String(r?.error || "").match(/Missing required field: (\w+)/);
    if (!m || vars[m[1]] !== undefined) break;
    vars[m[1]] = sampleFor(m[1], all[m[1]] || { type: "text" }, { profile: FIXTURE_PROFILE.WELL_FILLED });
  }
  if (!r?.draft) continue;
  for (const c of r.draft.clauses) {
    const e = usage.get(c.clause_id) || { types: [], words: 0 };
    e.types.push(docType);
    e.words = Math.max(e.words, String(c.text||"").split(/\s+/).filter(Boolean).length);
    usage.set(c.clause_id, e);
  }
}

// Every clause id a blueprint, a variant slot, or the drafting policies can
// reach -- which is a wider set than the ids that appear in the baseline sweep.
const blueprintReferenced = new Set();
{
  const BP = path.join(ROOT, "knowledge-base", "clause_library", "blueprints");
  for (const f of fs.readdirSync(BP)) {
    if (!f.endsWith(".json")) continue;
    const b = JSON.parse(fs.readFileSync(path.join(BP, f), "utf8"));
    for (const c of b.clauses || b.required_clauses || []) blueprintReferenced.add(typeof c === "string" ? c : c.clause);
    for (const e of b.conditional_clauses || []) blueprintReferenced.add(e.clause);
    for (const v of b.variant_clauses || []) {
      for (const c of v.select_first_match || v.variants || []) blueprintReferenced.add(c.clause);
      if (v.default) blueprintReferenced.add(v.default);
    }
  }
  const pol = JSON.parse(fs.readFileSync(path.join(ROOT, "knowledge-base", "metadata", "drafting_policies.json"), "utf8"));
  for (const id of pol?.defaults?.hardening?.baselineClauseIds || []) blueprintReferenced.add(id);
  for (const cfg of Object.values(pol?.documents || {})) {
    for (const id of cfg?.hardening?.requiredClauseIds || []) blueprintReferenced.add(id);
    for (const id of cfg?.hardening?.baselineClauseIds || []) blueprintReferenced.add(id);
  }
}

// Library metadata.
const LIB = path.join(ROOT, "knowledge-base", "clause_library");
const clauses = [];
for (const dir of fs.readdirSync(LIB, { withFileTypes: true })) {
  if (!dir.isDirectory() || dir.name === "blueprints") continue;
  for (const file of fs.readdirSync(path.join(LIB, dir.name))) {
    if (!file.endsWith(".json")) continue;
    const full = path.join(LIB, dir.name, file);
    let parsed;
    try { parsed = JSON.parse(fs.readFileSync(full, "utf8")); } catch { continue; }
    for (const c of (Array.isArray(parsed) ? parsed : [parsed])) {
      if (!c?.clause_id) continue;
      // A deprecated clause is not loaded by the engine and can never reach a
      // document. Putting it in the review pack asks the advocate to sign off
      // text the product cannot emit.
      if (c.deprecated === true) continue;
      const u = usage.get(c.clause_id) || { types: [], words: 0 };
      clauses.push({
        clause_id: c.clause_id,
        title: c.title || c.name || "",
        domain: dir.name,
        file: full,
        doc_types_reached: u.types.length,
        doc_types: u.types.join(", "),
        rendered_words: u.words,
        risk_level: c.risk_level || "",
        enforceability: c.enforceability || "",
        mandatory: c.mandatory === true,
        review_status: c.review_status || "unmarked",
        reviewed_by: c.reviewed_by || "",
        citations: (c.legal_basis || []).map(b => `${b.act||""} s.${b.section||""}`).join("; "),
        text: c.text || "",
        // The specific judgement the clause author could not make. This is the
        // most useful column in the pack: it turns "review this text" into a
        // concrete question, and it is where every deliberate drafting choice
        // and every unverified citation was recorded.
        authoring_note: c.authoring_note || "",
        statute_currency: c.statute_currency || "",
        // Why a clause reaches nothing matters. A clause no blueprint mentions is
        // dead. A conditional clause is alive but waits on a question this
        // fixture did not answer -- it will appear the moment a user answers it,
        // so it still needs review, just not first.
        reach_status: u.types.length > 0
          ? "in every generated draft that uses it"
          : (blueprintReferenced.has(c.clause_id)
              ? "conditional or variant -- reachable, but not triggered by the baseline fixture"
              : "NOT referenced by any blueprint or policy"),
      });
    }
  }
}

// Priority: reach across document types, weighted up for high risk and for
// clauses that are mandatory in the blueprint.
const RISK_WEIGHT = { HIGH: 3, MEDIUM: 2, LOW: 1, "": 1 };
for (const c of clauses) {
  c.priority =
    c.doc_types_reached * (RISK_WEIGHT[c.risk_level.toUpperCase()] || 1) +
    (c.mandatory ? 5 : 0) +
    // A clause with an authoring note carries a question already framed for the
    // advocate, so it is cheaper to decide and should not sink below untouched
    // boilerplate that merely appears in many documents.
    (c.authoring_note ? 8 : 0) +
    // Repointed to the labour Codes on 21 November 2025: the substance moved,
    // not just the citation, so these need a look before anything else.
    (c.statute_currency ? 12 : 0);
}
clauses.sort((a, b) => b.priority - a.priority);

fs.writeFileSync(path.join(ROOT, "reviewpack.json"), JSON.stringify(clauses, null, 1));
const reached = clauses.filter(c => c.doc_types_reached > 0);
const typeCount = Object.keys(DOCUMENT_TYPE_REGISTRY).length;
const conditional = clauses.filter(c => c.doc_types_reached === 0 && blueprintReferenced.has(c.clause_id));
const dead = clauses.filter(c => c.doc_types_reached === 0 && !blueprintReferenced.has(c.clause_id));
console.log(`${clauses.length} live clauses, ${reached.length} appear in a baseline draft of one of the ${typeCount} types`);
console.log(`${conditional.length} are conditional or variant -- reachable, awaiting a trigger the baseline fixture does not answer`);
console.log(`${dead.length} are referenced by no blueprint or policy at all\n`);
let cum = 0;
const totalPlacements = clauses.reduce((n,c)=>n+c.doc_types_reached,0);
for (const [n] of [[10],[20],[30],[50]]) {
  cum = clauses.slice(0,n).reduce((s,c)=>s+c.doc_types_reached,0);
  console.log(`  top ${String(n).padStart(3)} clauses cover ${String(cum).padStart(4)} of ${totalPlacements} clause placements (${Math.round(100*cum/totalPlacements)}%)`);
}
