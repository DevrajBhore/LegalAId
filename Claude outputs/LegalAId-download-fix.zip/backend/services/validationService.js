import { withValidationAssuranceWithdrawn } from "../../shared/documentWithdrawals.js";
import { validateAIIntegrity, userValueFigures } from "./mutationGuard.js";
import { getVariables as getSchemaVariables } from "../config/variableConfig.js";
import { validateRequirements, releaseOutcomeOf, RELEASE_LABEL } from "./requirementRelease.js";
import { verifySurvivalReferences } from "./survivalSemantics.js";
import { validateInstrumentCoherence, declaresInstrument, scopeUncertaintyToBindingProvisions, validateArticlesPrecedence } from "./instrumentCoherence.js";
import fs from "fs";
import { validateAgreementGraph } from "./agreementGraphValidator.js";

import { validate } from "../ire/runner.js";
import { summariseProvenance } from "../../shared/clauseProvenance.js";
import { buildStatutoryChecklistNotices } from "./statutoryChecklist.js";
import { commercialValidate } from "../ire/commercialValidator.js";
import { validateDraftConsistency } from "./draftConsistencyValidator.js";
import { validateNumericPlausibility } from "./numericPlausibilityValidator.js";
import { validatePartyIdentity } from "./partyIdentityValidator.js";
import { resolveStatutoryCitations } from "./statutoryCitationResolver.js";
import { computeDeadlines } from "./statutoryDeadlines.js";
import { validateDocumentHardening } from "./documentHardening.js";
import { validateClauseQuality } from "./clauseQualityNormalizer.js";
import { validateDocumentQuality } from "./documentQualityControl.js";

const COVERAGE_FILE = new URL(
  "../../knowledge-base/metadata/verification_coverage.json",
  import.meta.url
);

let coverageCache = null;

function loadCoverageDisclosure() {
  if (coverageCache === null) {
    try {
      coverageCache = JSON.parse(fs.readFileSync(COVERAGE_FILE, "utf8"));
    } catch {
      coverageCache = { not_machine_verified: [], by_document_type: {} };
    }
  }
  return coverageCache;
}

// What this run actually checked, and what it could not. Reported alongside the
// issues so an empty issue list is never presented as "legally compliant" -- it
// means the checks that ran found nothing, which is a different statement.
function buildCoverage({ documentType, layersRun, layersSkipped, constraintOutcomes, clauses }) {
  const disclosure = loadCoverageDisclosure();
  const outcomes = Array.isArray(constraintOutcomes) ? constraintOutcomes : [];
  const counted = (name) => outcomes.filter((entry) => entry.outcome === name).length;

  // How much of THIS document has actually been through legal review. Reported
  // beside the issue list so an empty issue list is never read as "an advocate
  // has approved this".
  const provenance = summariseProvenance(clauses || []);

  return {
    layers_run: layersRun,
    layers_skipped: layersSkipped,
    clause_review: {
      total_clauses: provenance.total,
      advocate_reviewed: provenance.reviewed,
      awaiting_review: provenance.awaiting_review,
      unmarked: provenance.unmarked,
      reviewed_fraction: provenance.reviewed_fraction,
    },
    rules_evaluated: outcomes.length,
    rules_passed: counted("pass"),
    rules_failed: counted("fail"),
    rules_not_applicable: counted("not_applicable"),
    // A DEFAULT THE USER TURNED DOWN — not a rule the document failed.
    //
    // The general provisions are a default set: the list lives under
    // `defaults.hardening`, every rule is MEDIUM and worded "should", and the
    // intake calls the four gated members optional protection while offering
    // "No". So declining one is the user exercising a choice the product put in
    // front of them, and reporting it as a failure would be the system marking
    // its own offer as a defect.
    //
    // Counted and NAMED rather than dropped. A clause the user declined is
    // exactly the thing a reader of the document should be told about — it is
    // absent on purpose, and only this line says so.
    rules_declined: counted("declined"),
    declined_defaults: outcomes
      .filter((entry) => entry.outcome === "declined")
      .map((entry) => ({
        rule_id: entry.rule_id,
        clause_ids: entry.declined_clause_ids || [],
      })),
    not_machine_verified: [
      ...(disclosure.not_machine_verified || []),
      ...((disclosure.by_document_type || {})[documentType] || []),
    ],
  };
}

function resolveSourceVariables(draft, sourceVariables) {
  if (sourceVariables && typeof sourceVariables === "object") {
    return sourceVariables;
  }

  if (draft?.metadata?.source_variables) {
    return draft.metadata.source_variables;
  }

  if (draft?.source_variables) {
    return draft.source_variables;
  }

  return null;
}

function resolveIsUserEdit(draft, isUserEdit) {
  if (typeof isUserEdit === "boolean") {
    return isUserEdit;
  }

  return Boolean(
    draft?.metadata?.user_edited ||
      draft?.metadata?.ai_touched ||
      draft?.metadata?.review_state === "edited"
  );
}

export async function runDocumentValidation(
  draft,
  {
    mode = "final",
    documentType,
    extraIssues = [],
    sourceVariables,
    isUserEdit,
  } = {}
) {
  const resolvedDocumentType = documentType || draft?.document_type;
  const resolvedSourceVariables = resolveSourceVariables(draft, sourceVariables);
  const layersRun = [];
  const layersSkipped = [];

  const coreValidation = await validate(draft, {
    mode,
    isUserEdit: resolveIsUserEdit(draft, isUserEdit),
  });
  layersRun.push("rule_engine");

  const runLayer = (name, condition, run, skipReason) => {
    if (!condition) {
      layersSkipped.push({ layer: name, reason: skipReason });
      return [];
    }
    layersRun.push(name);
    return run();
  };

  const commercialIssues = runLayer(
    "commercial",
    Boolean(resolvedDocumentType),
    () => commercialValidate(draft, resolvedDocumentType),
    "document type unknown"
  );
  const consistencyIssues = runLayer(
    "input_consistency",
    Boolean(resolvedDocumentType && resolvedSourceVariables),
    () =>
      validateDraftConsistency(draft, {
        documentType: resolvedDocumentType,
        variables: resolvedSourceVariables,
      }),
    resolvedDocumentType
      ? "the submitted form values were not available to compare against"
      : "document type unknown"
  );
  // Figures, checked as figures. This runs off the submitted form values rather
  // than the assembled prose: a wrong number is cheap to fix at intake and
  // expensive once it has been repeated across three clauses and a schedule.
  const plausibilityIssues = runLayer(
    "input_plausibility",
    Boolean(resolvedDocumentType && resolvedSourceVariables),
    () =>
      validateNumericPlausibility({
        documentType: resolvedDocumentType,
        variables: resolvedSourceVariables,
      }),
    resolvedDocumentType
      ? "the submitted form values were not available to check"
      : "document type unknown"
  );
  // Who the parties are, checked as identities: the shape of each statutory
  // number, whether two parties are secretly the same person, and whether the
  // declared entity type agrees with the name and the PAN holder code.
  const identityIssues = runLayer(
    "party_identity",
    Boolean(resolvedDocumentType && resolvedSourceVariables),
    () =>
      validatePartyIdentity({
        documentType: resolvedDocumentType,
        variables: resolvedSourceVariables,
      }),
    resolvedDocumentType
      ? "the submitted form values were not available to check"
      : "document type unknown"
  );
  // Citations, read against the date the document takes effect. The library
  // cites the law as it stands; whether that is the right law for THIS document
  // depends on its effective date, and no clause can answer that for itself.
  const citationIssues = runLayer(
    "statutory_currency",
    Boolean(resolvedDocumentType),
    () =>
      resolveStatutoryCitations(draft, {
        effectiveDate:
          resolvedSourceVariables?.effective_date ||
          resolvedSourceVariables?.start_date ||
          resolvedSourceVariables?.agreement_date,
      }),
    "document type unknown"
  );
  // Dates, checked as dates. A notice sent on the thirty-first day after the
  // return memo is not a late notice - it is no notice at all, and nothing in
  // the prose will tell the reader that.
  const deadlineIssues = runLayer(
    "statutory_deadlines",
    Boolean(resolvedDocumentType && resolvedSourceVariables),
    () => computeDeadlines(resolvedDocumentType, resolvedSourceVariables).issues,
    resolvedDocumentType
      ? "the submitted form values were not available to check"
      : "document type unknown"
  );
  const hardeningIssues = runLayer(
    "hardening",
    Boolean(resolvedDocumentType),
    () => validateDocumentHardening(draft, { documentType: resolvedDocumentType }),
    "document type unknown"
  );
  layersRun.push("clause_quality");
  const clauseQualityIssues = validateClauseQuality(draft);
  const statutoryChecklistNotices = runLayer(
    "statutory_checklist",
    Boolean(resolvedDocumentType),
    () => buildStatutoryChecklistNotices(resolvedDocumentType),
    "document type unknown"
  );
  // Graph-level checks: a clause that refers to a provision, a party capacity or
  // a place the rest of the document does not carry. Run last, because it needs
  // the assembled document rather than any single clause.
  const graphIssues = runLayer(
    "agreement_graph",
    Boolean(resolvedDocumentType),
    () =>
      validateAgreementGraph(draft, {
        documentType: resolvedDocumentType,
        variables: resolvedSourceVariables || {},
      }),
    "document type unknown"
  );
  // D4.44. The rendered document read as a whole, against what the instrument
  // declares itself to be. Runs only where the drafting policy declares an
  // instrument, and is otherwise neither run nor reported as skipped, so no
  // other document type's result changes.
  const coherenceIssues = declaresInstrument(resolvedDocumentType)
    ? (layersRun.push("instrument_coherence"),
      validateInstrumentCoherence(draft, {
        documentType: resolvedDocumentType,
        variables: resolvedSourceVariables || {},
      }))
    : [];
  // D4.45: a contract said to prevail over the Articles, in any document.
  const articlesIssues = validateArticlesPrecedence(draft);
  // D4.46: AI output checked against the immutable pre-AI text. Only AI-touched
  // drafts carry metadata.pre_ai_baseline, so nothing else is affected.
  const aiIntegrityIssues = draft?.metadata?.pre_ai_baseline
    ? (layersRun.push("ai_integrity"),
      validateAIIntegrity(draft, {
        userFigures: userValueFigures(resolvedSourceVariables || {}, getSchemaVariables(resolvedDocumentType) || {}),
      }))
    : [];
  // D4.46: what this KIND of document must do, deciding release. The one
  // requirement evaluator (assessRequirements), read in five states; see
  // requirementRelease.js. Families without a requirements file are unaffected.
  const requirementCheck = resolvedDocumentType
    ? validateRequirements(draft, { documentType: resolvedDocumentType, variables: resolvedSourceVariables || {} })
    : { issues: [], ledger: null };
  if (requirementCheck.ledger) layersRun.push("requirements");
  const requirementIssues = requirementCheck.issues;
  // D4.47: the survival list as printed, against the provisions the document
  // contains. Runs on every document; a list the engine drew is right by
  // construction, so this fires on edits and on defects.
  layersRun.push("survival_references");
  const survivalIssues = verifySurvivalReferences(draft);
  const finalQualityIssues = runLayer(
    "document_quality",
    Boolean(resolvedDocumentType),
    () =>
      validateDocumentQuality(draft, {
        documentType: resolvedDocumentType,
        variables: resolvedSourceVariables || {},
      }),
    "document type unknown"
  );

  // A withdrawn type keeps every finding, but loses its score and its "no issues"
  // band: the checks below are known to have passed a defective output of it.
  return withValidationAssuranceWithdrawn(formatValidationResult({
    mode: coreValidation.mode || mode,
    issues: [
      ...scopeUncertaintyToBindingProvisions(coreValidation.issues || [], draft, resolvedDocumentType),
      ...commercialIssues,
      ...consistencyIssues,
      ...plausibilityIssues,
      ...identityIssues,
      ...citationIssues,
      ...deadlineIssues,
      ...hardeningIssues,
      ...clauseQualityIssues,
      ...graphIssues,
      ...finalQualityIssues,
      ...coherenceIssues,
      ...articlesIssues,
      ...aiIntegrityIssues,
      ...requirementIssues,
      ...survivalIssues,
      ...statutoryChecklistNotices,
      ...extraIssues,
    ],
    layers: {
      ...(coreValidation._layers || {}),
      commercial_issues: commercialIssues.length,
      consistency_issues: consistencyIssues.length,
      hardening_issues: hardeningIssues.length,
      clause_quality_issues: clauseQualityIssues.length,
      agreement_graph_issues: graphIssues.length,
      final_quality_issues: finalQualityIssues.length,
      ...(coherenceIssues.length ? { instrument_coherence_issues: coherenceIssues.length } : {}),
      ...(requirementIssues.length ? { requirement_issues: requirementIssues.length } : {}),
      statutory_checklist_items: statutoryChecklistNotices[0]?.items?.length || 0,
      extra_issues: extraIssues.length,
    },
    coverage: buildCoverage({
      documentType: resolvedDocumentType,
      layersRun,
      layersSkipped,
      constraintOutcomes:
        coreValidation.constraint_outcomes || coreValidation._constraint_outcomes,
      clauses: draft?.clauses || [],
    }),
    requirements: requirementCheck.ledger,
  }), resolvedDocumentType, draft);
}

export function formatValidationResult({
  mode = "final",
  issues = [],
  layers = {},
  coverage = null,
  requirements = null,
} = {}) {
  const dedupedIssues = collapseClauseIssueNoise(deduplicateIssues(issues));
  const notices = dedupedIssues.filter(isNoticeIssue);
  const actionableIssues = dedupedIssues.filter((issue) => !isNoticeIssue(issue));
  const blockingIssues = actionableIssues.filter(isBlockingIssue);
  const advisoryIssues = actionableIssues.filter(
    (issue) => !isBlockingIssue(issue)
  );
  
  let critical = 0, high = 0, medium = 0, low = 0;
  
  actionableIssues.forEach(issue => {
    if (issue.severity === "CRITICAL" || issue.blocks_generation) critical++;
    else if (issue.severity === "HIGH") high++;
    else if (issue.severity === "MEDIUM") medium++;
    else low++;
  });

  // Weighted score, plus the arithmetic that produced it. "Why is this 92 and
  // not 100?" was unanswerable from the output: the score appeared as a bare
  // number with no way to see which findings cost what. Every deduction is now
  // itemised, so the number can be traced back to named issues.
  const SEVERITY_WEIGHTS = { CRITICAL: 40, HIGH: 20, MEDIUM: 10, LOW: 2 };

  const deductions = actionableIssues.map((issue) => {
    const severity =
      issue.severity === "CRITICAL" || issue.blocks_generation
        ? "CRITICAL"
        : ["HIGH", "MEDIUM", "LOW"].includes(issue.severity)
          ? issue.severity
          : "LOW";
    return {
      rule_id: issue.rule_id || "UNKNOWN_RULE",
      severity,
      points: SEVERITY_WEIGHTS[severity],
      message: issue.message || null,
      offending_clause_id: issue.offending_clause_id || null,
    };
  });

  const deducted = deductions.reduce((total, entry) => total + entry.points, 0);
  let score = Math.max(0, 100 - deducted);

  const scoreBreakdown = {
    starting_score: 100,
    deducted,
    final_score: score,
    weights: SEVERITY_WEIGHTS,
    // Notices (stamp duty, registration, statutory checklist) never cost points
    // -- they are information, not defects. Counted here so their absence from
    // the arithmetic is visible rather than mysterious.
    notices_excluded: notices.length,
    deductions: deductions.sort((left, right) => right.points - left.points),
  };

  // Verification band. Deliberately NOT the word "certified": passing means the
  // checks that ran found nothing, which is a narrower claim than compliance.
  // The `certified` field below is retained as the internal export gate.
  // "Automated checks passed", not "No issues detected" (D4.44). A term sheet
  // that contradicted itself on whether it binds was shown "No issues detected"
  // with a score of 100. The checks that ran found nothing; that is all a clean
  // result can claim, and the wording now says exactly that.
  //
  // D4.46: two further outcomes, distinct from both Blocked and passed. A
  // finding that needs an answer the user has not given is "Requires
  // information"; one that needs a lawyer's judgment is "Requires legal
  // review". A blocking finding always wins (see releaseOutcomeOf).
  const releaseOutcome = releaseOutcomeOf(blockingIssues, actionableIssues);
  const certification = RELEASE_LABEL[releaseOutcome];

  let overallRisk = "LOW";
  if (blockingIssues.length > 0) overallRisk = "BLOCKED";
  else if (high > 0) overallRisk = "HIGH";
  else if (medium > 0) overallRisk = "MEDIUM";

  return {
    mode,
    score,
    score_breakdown: scoreBreakdown,
    certification,
    release_outcome: releaseOutcome,
    risk: overallRisk,
    overall_risk: overallRisk,
    risk_level: overallRisk,
    // Internal gate flag consumed by the generation and export paths. It means
    // "every check that ran passed", not "this document is legally compliant".
    certified: actionableIssues.length === 0,
    checks_passed: actionableIssues.length === 0,
    coverage,
    ...(requirements ? { requirements } : {}),
    blockingIssues,
    advisoryIssues,
    notices,
    noticeCount: notices.length,
    issues: blockingIssues,
    advisory_issues: advisoryIssues,
    issueCount: actionableIssues.length,
    issue_count: blockingIssues.length,
    openIssueCount: actionableIssues.length,
    open_issue_count: actionableIssues.length,
    layers: layers || {},
    issues_summary: {
      critical,
      high,
      medium,
      low,
      notices: notices.length,
      total: actionableIssues.length
    },
    summary: {
      blocking: blockingIssues.length,
      advisory: advisoryIssues.length,
      notices: notices.length,
      total: actionableIssues.length,
    },
  };
}

function isBlockingIssue(issue) {
  return issue?.blocks_generation === true || issue?.severity === "CRITICAL";
}

function impactsCertification(issue) {
  if (!issue) return false;
  if (isBlockingIssue(issue)) return true;
  if (issue.stamp_advisory === true) return false;
  if (issue.recommendation_only === true) return false;
  if (issue.manual_review_required === true) return true;
  return false;
}

function isNoticeIssue(issue) {
  return issue?.stamp_advisory === true || issue?.notice_only === true;
}

function deduplicateIssues(issues = []) {
  const seen = new Set();
  return issues.filter((issue) => {
    const key = [
      issue?.rule_id || "UNKNOWN_RULE",
      issue?.offending_clause_id || "",
      issue?.message || "",
    ].join("|");
    if (seen.has(key)) return false;
    seen.add(key);
    if (!issue?.rule_id) return true;
    return true;
  });
}

function getClauseIssuePriority(issue) {
  const ruleId = issue?.rule_id || "";

  if (ruleId === "CLAUSE_TAMPER_DETECTED") return 100;
  if (ruleId === "AI_INTEGRITY_VIOLATION") return 95;
  if (ruleId.startsWith("AI_SEMANTIC_")) return 90;
  if (ruleId === "AI_CHECK_UNAVAILABLE") return 80;
  if (ruleId.startsWith("INPUT_MISMATCH_")) return 70;
  if (ruleId.startsWith("CLAUSE_TEXT_")) return 30;

  return isBlockingIssue(issue) ? 60 : 40;
}

function collapseClauseIssueNoise(issues = []) {
  const issuesByClause = new Map();
  const passthrough = [];

  for (const issue of issues) {
    const clauseId = issue?.offending_clause_id;
    if (!clauseId) {
      passthrough.push(issue);
      continue;
    }

    if (!issuesByClause.has(clauseId)) {
      issuesByClause.set(clauseId, []);
    }

    issuesByClause.get(clauseId).push(issue);
  }

  const collapsed = [];

  for (const clauseIssues of issuesByClause.values()) {
    const sortedIssues = [...clauseIssues].sort(
      (left, right) => getClauseIssuePriority(right) - getClauseIssuePriority(left)
    );
    const primaryIssue = sortedIssues[0];
    const primaryPriority = getClauseIssuePriority(primaryIssue);

    if (primaryPriority >= 95) {
      collapsed.push(primaryIssue);
      continue;
    }

    collapsed.push(...sortedIssues);
  }

  return [...passthrough, ...collapsed];
}
